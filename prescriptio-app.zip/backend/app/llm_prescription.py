import json
import os
import re
from typing import Any, Dict, List

import requests

LLAMA_CHAT_URL = os.getenv(
    "LLAMA_CHAT_URL",
    "http://127.0.0.1:8081/v1/chat/completions",
)

LLAMA_MODEL = os.getenv("LLAMA_MODEL", "local")

SYSTEM = (
    "You are a clinical documentation and prescription assistant for Indian doctors. "
    "Return STRICT JSON only. "
    "Do NOT invent facts. "
    "IGNORE non-medical conversation, filler, jokes, greetings, and unrelated speech. "
    "Extract only clinically relevant information. "
    "Preserve all medication details carefully. "
    "If a field is unknown, use empty string or empty list."
)

SCHEMA: Dict[str, Any] = {
    "meta": {
        "is_valid_prescription": True,
        "rejection_reason": "",
    },
    "patient": {
        "name": "",
        "age": "",
        "sex": "",
        "id": "",
        "allergies": [],
        "known_conditions": [],
    },
    "encounter": {
        "chief_complaints": [],
        "history_of_present_illness": "",
        "exam_notes": "",
        "vitals": {
            "temperature": "",
            "bp": "",
            "pulse": "",
            "rr": "",
            "spo2": "",
            "weight": "",
        },
    },
    "assessment": {
        "diagnosis_primary": "",
        "diagnosis_secondary": [],
        "differentials": [],
    },
    "plan": {
        "medications": [
            {
                "name": "",
                "strength": "",
                "form": "",
                "route": "",
                "dose_pattern": "",
                "timing": "",
                "duration": "",
                "quantity": "",
                "instructions": "",
                "indication": "",
                "status": "",
                "prn": "",
            }
        ],
        "investigations": [],
        "advice": [],
        "referrals": [],
        "follow_up": "",
    },
    "safety": {
        "red_flags": [],
        "when_to_return": [],
        "drug_warnings": [],
    },
    "quality": {
        "missing_information_questions": [],
        "confidence": {"overall": 0.0},
    },
}


def _clean(s: Any) -> str:
    return str(s).strip() if s is not None else ""


def _normalize_list(items) -> List[str]:
    if not items:
        return []
    out = []
    for x in items:
        if isinstance(x, str):
            out.append(x.strip())
        elif isinstance(x, dict):
            out.append(
                str(
                    x.get("name")
                    or x.get("title")
                    or x.get("value")
                    or x.get("text")
                    or x.get("test")
                    or ""
                ).strip()
            )
        else:
            out.append(str(x).strip())
    return [s for s in out if s]


def _extract_json(text: str) -> dict:
    a = text.find("{")
    b = text.rfind("}")
    if a != -1 and b != -1 and b > a:
        text = text[a : b + 1]
    return json.loads(text)


def safe_extract_json(text: str) -> dict:
    try:
        return json.loads(text)
    except Exception:
        return json.loads(json.dumps(SCHEMA))


NUM_WORDS = {
    "zero": 0,
    "oh": 0,
    "o": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "eleven": 11,
    "twelve": 12,
    "thirteen": 13,
    "fourteen": 14,
    "fifteen": 15,
    "sixteen": 16,
    "seventeen": 17,
    "eighteen": 18,
    "nineteen": 19,
    "twenty": 20,
    "thirty": 30,
    "forty": 40,
    "fifty": 50,
    "sixty": 60,
    "seventy": 70,
    "eighty": 80,
    "ninety": 90,
}

MEDICAL_SIGNAL_WORDS = {
    "patient",
    "bp",
    "pulse",
    "temperature",
    "spo2",
    "rr",
    "weight",
    "history",
    "exam",
    "diagnosis",
    "complaint",
    "complaints",
    "medicine",
    "medication",
    "tablet",
    "tab",
    "capsule",
    "cap",
    "syrup",
    "injection",
    "inj",
    "mg",
    "ml",
    "dose",
    "dosage",
    "once",
    "twice",
    "thrice",
    "daily",
    "od",
    "bd",
    "tds",
    "hs",
    "before food",
    "after food",
    "follow up",
    "review",
    "investigation",
    "advice",
    "referral",
    "fever",
    "cough",
    "pain",
    "hypertension",
    "diabetes",
    "paracetamol",
    "amlodipine",
    "metformin",
}

NON_MEDICAL_NOISE_PATTERNS = [
    r"\byeah\b",
    r"\boh\b",
    r"\bwhat what\b",
    r"\bfish\b",
    r"\bprofessor\b",
    r"\bx x\b",
]


def _tokenize_words(s: str) -> List[str]:
    s = _clean(s).lower().replace("-", " ")
    s = re.sub(r"[^a-z0-9.\s]", " ", s)
    return [t for t in s.split() if t]


def _words_to_int(text: str) -> str:
    text = _clean(text).lower()
    if not text:
        return ""

    if re.fullmatch(r"\d+", text):
        return text

    tokens = _tokenize_words(text)
    if not tokens:
        return ""

    if all(t in NUM_WORDS and NUM_WORDS[t] < 10 for t in tokens):
        return "".join(str(NUM_WORDS[t]) for t in tokens)

    if (
        len(tokens) in {2, 3}
        and tokens[0] in NUM_WORDS
        and NUM_WORDS[tokens[0]] < 10
        and tokens[1] in NUM_WORDS
        and NUM_WORDS[tokens[1]] >= 20
        and all(t in NUM_WORDS for t in tokens[1:])
    ):
        first = str(NUM_WORDS[tokens[0]])
        rest_val = sum(NUM_WORDS[t] for t in tokens[1:])
        return first + f"{rest_val:02d}"

    total = 0
    current = 0

    for tok in tokens:
        if tok in NUM_WORDS:
            current += NUM_WORDS[tok]
        elif tok == "hundred":
            if current == 0:
                current = 1
            current *= 100
        elif tok == "thousand":
            if current == 0:
                current = 1
            total += current * 1000
            current = 0
        elif tok.isdigit():
            current += int(tok)

    total += current
    return str(total) if total or text.strip() == "zero" else ""


def _words_to_decimal(text: str) -> str:
    text = _clean(text).lower()
    if not text:
        return ""

    if "point" not in text:
        return _words_to_int(text)

    left, right = text.split("point", 1)
    left_num = _words_to_int(left.strip())
    right_tokens = _tokenize_words(right)
    right_digits = []

    for tok in right_tokens:
        if tok in NUM_WORDS and NUM_WORDS[tok] < 10:
            right_digits.append(str(NUM_WORDS[tok]))
        elif tok.isdigit():
            right_digits.append(tok)

    if left_num and right_digits:
        return f"{left_num}.{''.join(right_digits)}"
    return left_num


def _normalize_bp_value(text: str) -> str:
    t = _clean(text).lower().replace("mm hg", "").replace("mmhg", "").strip()
    if not t:
        return ""

    m = re.search(r"(\d{2,3})\s*(?:/|by|over)\s*(\d{2,3})", t, re.I)
    if m:
        return f"{m.group(1)}/{m.group(2)} mmHg"

    parts = re.split(r"\b(?:by|over|/)\b", t)
    if len(parts) >= 2:
        left = _words_to_int(parts[0].strip())
        right = _words_to_int(parts[1].strip())
        if left and right:
            return f"{left}/{right} mmHg"

    return _clean(text)


def _normalize_pulse_value(text: str) -> str:
    t = _clean(text).lower().replace("beats per minute", "").replace("bpm", "").strip()
    if not t:
        return ""

    m = re.search(r"(\d{2,3})", t)
    if m:
        return f"{m.group(1)} bpm"

    num = _words_to_int(t)
    if num:
        return f"{num} bpm"

    return _clean(text)


def _normalize_rr_value(text: str) -> str:
    t = _clean(text).lower().replace("breaths per minute", "").replace("/min", "").strip()
    if not t:
        return ""

    m = re.search(r"(\d{1,3})", t)
    if m:
        return m.group(1)

    num = _words_to_int(t)
    return num or _clean(text)


def _normalize_spo2_value(text: str) -> str:
    t = _clean(text).lower().replace("percent", "").replace("%", "").strip()
    if not t:
        return ""

    m = re.search(r"(\d{2,3})", t)
    if m:
        return f"{m.group(1)}%"

    num = _words_to_int(t)
    return f"{num}%" if num else _clean(text)


def _normalize_temp_value(text: str) -> str:
    t = _clean(text).lower()
    if not t:
        return ""

    unit = ""
    if "fahrenheit" in t or re.search(r"\bf\b", t):
        unit = " F"
    elif "celsius" in t or re.search(r"\bc\b", t):
        unit = " C"

    t = (
        t.replace("fahrenheit", "")
        .replace("celsius", "")
        .replace("degree", "")
        .replace("degrees", "")
    )
    t = re.sub(r"\b([fc])\b", " ", t).strip()

    m = re.search(r"(\d+(\.\d+)?)", t)
    if m:
        return m.group(1) + unit

    num = _words_to_decimal(t)
    return (num + unit) if num else _clean(text)


def _normalize_weight_value(text: str) -> str:
    t = _clean(text).lower()
    if not t:
        return ""

    unit = " kg" if any(x in t for x in ["kg", "kilogram", "kilograms", "kilo", "kilos"]) else ""

    t = (
        t.replace("kilograms", "")
        .replace("kilogram", "")
        .replace("kilos", "")
        .replace("kilo", "")
        .replace("kg", "")
        .strip()
    )

    m = re.search(r"(\d+(\.\d+)?)", t)
    if m:
        return m.group(1) + unit

    num = _words_to_decimal(t)
    return (num + unit) if num else _clean(text)


def _normalize_vitals_numbers(rx: dict) -> dict:
    vit = rx.get("encounter", {}).get("vitals", {})
    if not isinstance(vit, dict):
        return rx

    if vit.get("bp"):
        vit["bp"] = _normalize_bp_value(vit["bp"])
    if vit.get("pulse"):
        vit["pulse"] = _normalize_pulse_value(vit["pulse"])
    if vit.get("rr"):
        vit["rr"] = _normalize_rr_value(vit["rr"])
    if vit.get("spo2"):
        vit["spo2"] = _normalize_spo2_value(vit["spo2"])
    if vit.get("temperature"):
        vit["temperature"] = _normalize_temp_value(vit["temperature"])
    if vit.get("weight"):
        vit["weight"] = _normalize_weight_value(vit["weight"])

    rx["encounter"]["vitals"] = vit
    return rx


def _freq_to_pattern(freq: str) -> str:
    f = _clean(freq).lower()

    if re.fullmatch(r"\d-\d-\d", f):
        return f
    if "tds" in f or "thrice" in f or "three times" in f:
        return "1-1-1"
    if "bd" in f or "twice" in f or "two times" in f:
        return "1-0-1"
    if "od" in f or "once daily" in f or f == "once":
        return "once daily"
    if "qhs" in f or "hs" in f or "bedtime" in f or "night" in f:
        return "0-0-1"
    if "q6h" in f or "every 6" in f:
        return "q6h"
    if "q8h" in f or "every 8" in f:
        return "q8h"
    if "q12h" in f or "every 12" in f:
        return "q12h"

    return _clean(freq)


def _infer_timing(text: str) -> str:
    t = _clean(text).lower()

    if "before breakfast" in t:
        return "Before breakfast"
    if "after breakfast" in t:
        return "After breakfast"
    if "before lunch" in t:
        return "Before lunch"
    if "after lunch" in t:
        return "After lunch"
    if "before dinner" in t:
        return "Before dinner"
    if "after dinner" in t:
        return "After dinner"
    if "bedtime" in t or "night" in t or "hs" in t:
        return "At bedtime"
    if "before food" in t or "empty stomach" in t:
        return "Before food"
    if "after food" in t or "with food" in t:
        return "After food"
    if "morning" in t:
        return "Morning"
    if "evening" in t:
        return "Evening"

    return ""


def _correct_pattern_by_timing(dose_pattern: str, timing: str) -> str:
    dp = _clean(dose_pattern)
    tm = _clean(timing).lower()

    if not tm:
        return dp

    if tm in {"at bedtime", "night", "bedtime"} and dp in {"1-0-0", "once daily", "od"}:
        return "0-0-1"

    if tm == "morning" and dp in {"0-0-1", "once daily"}:
        return "1-0-0"

    if dp == "once daily" and tm not in {"morning", "at bedtime", "night", "bedtime"}:
        return "1-0-0"

    return dp


def _infer_prn(instructions: str, timing: str, indication: str) -> str:
    txt = " ".join([_clean(instructions), _clean(timing), _clean(indication)]).lower()
    if any(x in txt for x in ["as needed", "prn", "if needed", "rescue medication"]):
        return "yes"
    return ""


def _infer_status(text: str) -> str:
    t = _clean(text).lower()
    if "continue" in t:
        return "continue"
    if "restart" in t:
        return "restart"
    if "stop" in t:
        return "stop"
    if "start" in t or "add" in t or "prescribe" in t:
        return "start"
    return ""


def _looks_like_strength(text: str) -> bool:
    t = _clean(text).lower()
    return bool(re.fullmatch(r"\d+(\.\d+)?\s*(mg|mcg|g|ml|units?)", t))


def _normalize_quantity(quantity: str, strength: str) -> str:
    q = _clean(quantity)
    s = _clean(strength)

    if not q:
        return ""
    if q.lower() == s.lower():
        return ""
    if _looks_like_strength(q):
        return ""
    return q


def _normalize_medication(m: dict) -> dict:
    name = _clean(m.get("name"))
    strength = _clean(m.get("strength"))
    form = _clean(m.get("form"))
    route = _clean(m.get("route"))

    raw_dose_pattern = _clean(m.get("dose_pattern"))
    raw_timing = _clean(m.get("timing"))
    instructions = _clean(m.get("instructions"))
    indication = _clean(m.get("indication"))
    status = _clean(m.get("status"))
    prn = _clean(m.get("prn"))

    dose_pattern = _freq_to_pattern(raw_dose_pattern)
    timing = raw_timing or _infer_timing(" ".join([instructions, indication, raw_timing]))
    dose_pattern = _correct_pattern_by_timing(dose_pattern, timing)

    duration = _clean(m.get("duration"))
    quantity = _normalize_quantity(m.get("quantity"), strength)

    if timing.lower() == "night":
        timing = "At bedtime"
    if not prn:
        prn = _infer_prn(instructions, timing, indication)
    if not status:
        status = _infer_status(" ".join([instructions, indication, raw_dose_pattern]))

    return {
        "name": name,
        "strength": strength,
        "form": form,
        "route": route,
        "dose_pattern": dose_pattern,
        "timing": timing,
        "duration": duration,
        "quantity": quantity,
        "instructions": instructions,
        "indication": indication,
        "status": status,
        "prn": prn,
    }


def filter_medications(meds: List[dict]) -> List[dict]:
    filtered = []
    for m in meds:
        if not isinstance(m, dict):
            continue
        nm = _normalize_medication(m)
        if nm["name"] and re.search(r"[a-zA-Z]", nm["name"]):
            filtered.append(nm)
    return filtered


def filter_diagnosis(dx_list: List[str]) -> List[str]:
    filtered = []
    for dx in dx_list:
        if re.search(r"[a-zA-Z]", dx) and len(dx.split()) <= 12:
            filtered.append(dx)
    return filtered


FOLLOW_UP_PATTERNS = [
    r"\breview after\b",
    r"\breview in\b",
    r"\bfollow[\s-]?up\b",
    r"\bcome back in\b",
    r"\breturn in\b",
    r"\brevisit in\b",
    r"\brepeat after\b",
]
REFERRAL_PATTERNS = [
    r"\brefer to\b",
    r"\bsurgical opinion\b",
    r"\bcounseling\b",
    r"\bphysiotherapy\b",
    r"\brehabilitation\b",
    r"\bgeneral surgery\b",
]
INVESTIGATION_PATTERNS = [
    r"\border\b",
    r"\bsend\b",
    r"\bcheck\b",
    r"\brepeat\b",
    r"\bmonitor\b",
    r"\btest\b",
    r"\bscreening\b",
    r"\bprofile\b",
    r"\bfunction tests?\b",
    r"\bultrasound\b",
    r"\bx[\s-]?ray\b",
    r"\becg\b",
    r"\bendoscopy\b",
    r"\bculture\b",
    r"\bhba1c\b",
    r"\bcbc\b",
    r"\blipid\b",
    r"\burine\b",
]
MEDICAL_KEYWORDS_ADVICE = [
    "rest",
    "fluids",
    "exercise",
    "diet",
    "medication",
    "inhaler",
    "gargle",
    "warm",
    "ice",
    "care",
    "hydration",
    "monitor",
    "avoid",
    "steam",
    "sleep",
    "drink",
    "salt",
    "walk",
    "smoking cessation",
    "weight reduction",
    "weight loss",
    "daily walking",
    "avoid allergens",
    "adequate hydration",
    "strict diabetic diet",
    "lifestyle",
]


def _looks_like_followup(text: str) -> bool:
    t = _clean(text).lower()
    return any(re.search(p, t) for p in FOLLOW_UP_PATTERNS)


def _looks_like_referral(text: str) -> bool:
    t = _clean(text).lower()
    return any(re.search(p, t) for p in REFERRAL_PATTERNS)


def _looks_like_investigation(text: str) -> bool:
    t = _clean(text).lower()
    return any(re.search(p, t) for p in INVESTIGATION_PATTERNS)


def filter_advice(advice_list: List[str]) -> List[str]:
    filtered = []
    for a in advice_list:
        al = a.lower()
        if any(k in al for k in MEDICAL_KEYWORDS_ADVICE) or not (
            _looks_like_followup(a) or _looks_like_referral(a) or _looks_like_investigation(a)
        ):
            filtered.append(a)
    return filtered


def _normalize_plan_sections(plan: dict) -> dict:
    advice_items = _normalize_list(plan.get("advice", []))
    investigation_items = _normalize_list(plan.get("investigations", []))
    referral_items = _normalize_list(plan.get("referrals", []))
    follow_up = _clean(plan.get("follow_up"))

    kept_advice = []
    kept_investigations = investigation_items[:]
    kept_referrals = referral_items[:]

    for item in advice_items:
        if _looks_like_followup(item):
            if not follow_up:
                follow_up = item
        elif _looks_like_referral(item):
            kept_referrals.append(item)
        elif _looks_like_investigation(item):
            kept_investigations.append(item)
        else:
            kept_advice.append(item)

    dedup_investigations = []
    seen = set()
    for x in kept_investigations:
        key = x.lower()
        if key not in seen:
            dedup_investigations.append(x)
            seen.add(key)

    dedup_referrals = []
    seen = set()
    for x in kept_referrals:
        key = x.lower()
        if key not in seen:
            dedup_referrals.append(x)
            seen.add(key)

    plan["advice"] = filter_advice(kept_advice)
    plan["investigations"] = dedup_investigations
    plan["referrals"] = dedup_referrals
    plan["follow_up"] = follow_up
    return plan


def _ensure_schema_shape(rx: dict) -> dict:
    rx.setdefault("meta", {})
    rx.setdefault("patient", {})
    rx.setdefault("encounter", {})
    rx.setdefault("assessment", {})
    rx.setdefault("plan", {})
    rx.setdefault("safety", {})
    rx.setdefault("quality", {})

    rx["meta"].setdefault("is_valid_prescription", True)
    rx["meta"].setdefault("rejection_reason", "")

    rx["patient"].setdefault("name", "")
    rx["patient"].setdefault("age", "")
    rx["patient"].setdefault("sex", "")
    rx["patient"].setdefault("id", "")
    rx["patient"].setdefault("allergies", [])
    rx["patient"].setdefault("known_conditions", [])

    rx["encounter"].setdefault("chief_complaints", [])
    rx["encounter"].setdefault("history_of_present_illness", "")
    rx["encounter"].setdefault("exam_notes", "")
    rx["encounter"].setdefault("vitals", {})
    rx["encounter"]["vitals"].setdefault("temperature", "")
    rx["encounter"]["vitals"].setdefault("bp", "")
    rx["encounter"]["vitals"].setdefault("pulse", "")
    rx["encounter"]["vitals"].setdefault("rr", "")
    rx["encounter"]["vitals"].setdefault("spo2", "")
    rx["encounter"]["vitals"].setdefault("weight", "")

    rx["assessment"].setdefault("diagnosis_primary", "")
    rx["assessment"].setdefault("diagnosis_secondary", [])
    rx["assessment"].setdefault("differentials", [])

    rx["plan"].setdefault("medications", [])
    rx["plan"].setdefault("investigations", [])
    rx["plan"].setdefault("advice", [])
    rx["plan"].setdefault("referrals", [])
    rx["plan"].setdefault("follow_up", "")

    rx["safety"].setdefault("red_flags", [])
    rx["safety"].setdefault("when_to_return", [])
    rx["safety"].setdefault("drug_warnings", [])

    rx["quality"].setdefault("missing_information_questions", [])
    rx["quality"].setdefault("confidence", {"overall": 0.0})

    return rx


def _regex_fill_vitals(rx: dict, source: str):
    enc = rx.setdefault("encounter", {})
    vit = enc.setdefault("vitals", {})
    s = source or ""

    if not vit.get("temperature"):
        m = re.search(r"(\d+(\.\d+)?)\s*°?\s*f", s, re.I)
        if m:
            vit["temperature"] = m.group(1) + " F"

    if not vit.get("bp"):
        m = re.search(r"(\d{2,3})\s*(/|over)\s*(\d{2,3})", s, re.I)
        if m:
            vit["bp"] = f"{m.group(1)}/{m.group(3)} mmHg"

    if not vit.get("pulse"):
        m = re.search(r"pulse\s*(\d{2,3})", s, re.I)
        if m:
            vit["pulse"] = m.group(1) + " bpm"

    if not vit.get("rr"):
        m = re.search(r"(rr|respiratory rate)\s*(\d{1,3})", s, re.I)
        if m:
            vit["rr"] = m.group(2)

    if not vit.get("spo2"):
        m = re.search(r"(spo2|oxygen saturation)\s*(\d{2,3})", s, re.I)
        if m:
            vit["spo2"] = m.group(2) + "%"


def _normalize_text_for_gate(text: str) -> str:
    text = _clean(text).lower()
    text = re.sub(r"[^a-z0-9\s:/.-]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _medical_signal_score(text: str) -> dict:
    t = _normalize_text_for_gate(text)
    if not t:
        return {
            "token_count": 0,
            "medical_hits": 0,
            "noise_hits": 0,
            "number_hits": 0,
            "colon_hits": 0,
            "score": 0.0,
        }

    token_count = len(t.split())

    medical_hits = 0
    for kw in MEDICAL_SIGNAL_WORDS:
        if kw in t:
            medical_hits += 1

    noise_hits = 0
    for pat in NON_MEDICAL_NOISE_PATTERNS:
        if re.search(pat, t):
            noise_hits += 1

    number_hits = len(re.findall(r"\b\d+(?:/\d+)?\b", t))
    colon_hits = len(
        re.findall(r"\b(patient|bp|pulse|history|exam|diagnosis|advice|follow[- ]?up)\s*:", t)
    )

    score = (medical_hits * 2.0) + (number_hits * 0.4) + (colon_hits * 1.5) - (noise_hits * 1.5)

    return {
        "token_count": token_count,
        "medical_hits": medical_hits,
        "noise_hits": noise_hits,
        "number_hits": number_hits,
        "colon_hits": colon_hits,
        "score": score,
    }


def _looks_like_valid_medical_dictation(text: str) -> bool:
    stats = _medical_signal_score(text)

    if stats["token_count"] < 4:
        return False
    if stats["medical_hits"] == 0:
        return False
    if stats["score"] < 2.5:
        return False

    return True


def _empty_invalid_rx(reason: str) -> dict:
    rx = json.loads(json.dumps(SCHEMA))
    rx["meta"]["is_valid_prescription"] = False
    rx["meta"]["rejection_reason"] = reason
    return rx


def _has_meaningful_prescription_content(rx: dict) -> bool:
    patient = rx.get("patient", {})
    enc = rx.get("encounter", {})
    ass = rx.get("assessment", {})
    plan = rx.get("plan", {})

    meds = plan.get("medications", []) or []
    valid_meds = [m for m in meds if isinstance(m, dict) and _clean(m.get("name"))]

    vit = enc.get("vitals", {}) or {}
    vitals_present = any(_clean(vit.get(k)) for k in ["temperature", "bp", "pulse", "rr", "spo2", "weight"])

    text_fields = [
        _clean(patient.get("name")),
        _clean(enc.get("history_of_present_illness")),
        _clean(enc.get("exam_notes")),
        _clean(ass.get("diagnosis_primary")),
        _clean(plan.get("follow_up")),
    ]

    list_fields_count = sum(
        [
            len(_normalize_list(enc.get("chief_complaints"))),
            len(_normalize_list(plan.get("investigations"))),
            len(_normalize_list(plan.get("advice"))),
            len(_normalize_list(plan.get("referrals"))),
        ]
    )

    if valid_meds:
        return True
    if vitals_present and any(text_fields):
        return True
    if _clean(ass.get("diagnosis_primary")) and list_fields_count > 0:
        return True
    if sum(1 for x in text_fields if x) >= 2:
        return True

    return False


def _postprocess(rx: dict, source: str) -> dict:
    rx = _ensure_schema_shape(rx)
    _regex_fill_vitals(rx, source)
    rx = _normalize_vitals_numbers(rx)

    plan = rx.get("plan", {})
    plan["medications"] = filter_medications(plan.get("medications", []))
    plan["investigations"] = _normalize_list(plan.get("investigations", []))
    plan["advice"] = _normalize_list(plan.get("advice", []))
    plan["referrals"] = _normalize_list(plan.get("referrals", []))
    plan = _normalize_plan_sections(plan)
    rx["plan"] = plan

    ass = rx.get("assessment", {})
    ass["diagnosis_secondary"] = filter_diagnosis(_normalize_list(ass.get("diagnosis_secondary", [])))
    primary = _clean(ass.get("diagnosis_primary"))
    ass["diagnosis_primary"] = primary if primary and filter_diagnosis([primary]) else ""
    rx["assessment"] = ass

    return rx


RX_CACHE: Dict[str, dict] = {}


def rx_from_text(dictation: str) -> dict:
    key = dictation.strip()
    if key in RX_CACHE:
        return RX_CACHE[key]

    if not _looks_like_valid_medical_dictation(dictation):
        rx = _empty_invalid_rx("Input does not contain enough medical or prescription information.")
        RX_CACHE[key] = rx
        return rx

    prompt = (
        "Extract structured prescription JSON from this doctor dictation.\n\n"
        "Important extraction rules:\n"
        "1. Return only valid JSON.\n"
        "2. If the input is non-medical, meaningless, noisy, or unrelated, set meta.is_valid_prescription to false.\n"
        "3. Extract patient details, vitals, complaints, history, diagnosis, medications, investigations, advice, referrals, follow-up, and safety.\n"
        "4. Preserve every medicine with name, strength, form, route, dose_pattern, timing, duration, quantity, instructions, indication, status, and prn if present.\n"
        "5. Put tests/labs/scans under investigations.\n"
        "6. Put lifestyle recommendations under advice.\n"
        "7. Put review/revisit/come back timing under follow_up.\n"
        "8. Put referral information under referrals.\n"
        "9. Preserve chronic continuation medicines if doctor says continue.\n"
        "10. If medicine is as needed, rescue medication, or sliding scale, preserve that meaning.\n"
        "11. Prefer prescription-style numeric vitals if possible.\n"
        "12. Do not invent missing values.\n"
        "13. If transcript is noise or unrelated speech, do not generate a prescription.\n\n"
        f"DICTATION:\n{dictation}\n\n"
        "Return JSON matching exactly this schema:\n"
        f"{json.dumps(SCHEMA, indent=2)}"
    )

    payload = {
        "model": LLAMA_MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 1600,
    }

    session = requests.Session()
    session.trust_env = False

    r = session.post(LLAMA_CHAT_URL, json=payload, timeout=240)
    r.raise_for_status()

    content = r.json()["choices"][0]["message"]["content"]

    try:
        rx = _extract_json(content)
    except Exception:
        rx = safe_extract_json(content)

    rx = _postprocess(rx, dictation)

    if not _has_meaningful_prescription_content(rx):
        rx = _empty_invalid_rx("No meaningful prescription content detected.")

    RX_CACHE[key] = rx
    return rx


def rx_markdown(rx: dict) -> str:
    meta = rx.get("meta", {})
    if meta.get("is_valid_prescription") is False:
        return ""

    p = rx.get("patient", {})
    enc = rx.get("encounter", {})
    vit = enc.get("vitals", {})
    ass = rx.get("assessment", {})
    plan = rx.get("plan", {})
    safety = rx.get("safety", {})

    lines: List[str] = []

    patient_line = (
        f"Patient: {_clean(p.get('name'))} | Age/Sex: {_clean(p.get('age'))} {_clean(p.get('sex'))}"
    ).strip()
    if patient_line.replace("Patient: | Age/Sex:", "").strip():
        lines.append(patient_line)

    if _clean(p.get("id")):
        lines.append(f"UHID: {_clean(p.get('id'))}")

    allergies = _normalize_list(p.get("allergies"))
    if allergies:
        lines.append("Allergies: " + ", ".join(allergies))

    conditions = _normalize_list(p.get("known_conditions"))
    if conditions:
        lines.append("Known conditions: " + ", ".join(conditions))

    v = []
    if vit.get("temperature"):
        v.append(f"Temp: {_clean(vit.get('temperature'))}")
    if vit.get("bp"):
        v.append(f"BP: {_clean(vit.get('bp'))}")
    if vit.get("pulse"):
        v.append(f"Pulse: {_clean(vit.get('pulse'))}")
    if vit.get("rr"):
        v.append(f"RR: {_clean(vit.get('rr'))}")
    if vit.get("spo2"):
        v.append(f"SpO2: {_clean(vit.get('spo2'))}")
    if vit.get("weight"):
        v.append(f"Weight: {_clean(vit.get('weight'))}")
    if v:
        lines.append("Vitals: " + " | ".join(v))

    complaints = _normalize_list(enc.get("chief_complaints"))
    if complaints:
        lines.append("Complaints: " + ", ".join(complaints))

    if _clean(enc.get("history_of_present_illness")):
        lines.append("History: " + _clean(enc.get("history_of_present_illness")))

    if _clean(enc.get("exam_notes")):
        lines.append("Exam: " + _clean(enc.get("exam_notes")))

    dx = []
    if ass.get("diagnosis_primary"):
        dx.append(_clean(ass.get("diagnosis_primary")))
    dx += _normalize_list(ass.get("diagnosis_secondary"))
    if dx:
        lines.append("Diagnosis: " + ", ".join(dx))

    meds = plan.get("medications", [])
    if meds:
        lines.append("\nMedications:")
        for i, m in enumerate(meds, 1):
            meta_parts = " | ".join(
                x
                for x in [
                    _clean(m.get("strength")),
                    _clean(m.get("form")),
                    _clean(m.get("route")),
                    _clean(m.get("dose_pattern")),
                    _clean(m.get("timing")),
                    f"x {_clean(m.get('duration'))}" if m.get("duration") else "",
                    f"Qty: {_clean(m.get('quantity'))}" if _clean(m.get("quantity")) else "",
                    f"Status: {_clean(m.get('status'))}" if _clean(m.get("status")) else "",
                    "PRN" if _clean(m.get("prn")).lower() == "yes" else "",
                ]
                if x
            )

            line = f"{i}. {_clean(m.get('name'))}"
            if meta_parts:
                line += f" — {meta_parts}"
            lines.append(line)

            if _clean(m.get("instructions")):
                lines.append("   Instructions: " + _clean(m.get("instructions")))
            if _clean(m.get("indication")):
                lines.append("   For: " + _clean(m.get("indication")))

    tests = _normalize_list(plan.get("investigations"))
    if tests:
        lines.append("\nInvestigations: " + ", ".join(tests))

    advice = _normalize_list(plan.get("advice"))
    if advice:
        lines.append("\nAdvice: " + ", ".join(advice))

    referrals = _normalize_list(plan.get("referrals"))
    if referrals:
        lines.append("\nReferrals: " + ", ".join(referrals))

    returns = _normalize_list(safety.get("when_to_return"))
    if returns:
        lines.append("\nReturn immediately if: " + ", ".join(returns))

    warnings = _normalize_list(safety.get("drug_warnings"))
    if warnings:
        lines.append("\nDrug warnings: " + ", ".join(warnings))

    if _clean(plan.get("follow_up")):
        lines.append("\nFollow-up: " + _clean(plan.get("follow_up")))

    return "\n".join(lines).strip()