# from __future__ import annotations

# from io import BytesIO
# from pathlib import Path
# import re
# from datetime import datetime
# from typing import Dict, List, Any

# from textwrap import wrap
# from reportlab.lib import colors
# from reportlab.lib.pagesizes import A4
# from reportlab.lib.units import mm
# from reportlab.pdfgen import canvas
# from reportlab.pdfbase.pdfmetrics import stringWidth
# from reportlab.lib.utils import ImageReader

# PAGE_W, PAGE_H = A4
# BLUE = colors.HexColor("#3a92b8")
# DARK = colors.HexColor("#1f2d3d")

# ASSET_DIR = Path(__file__).resolve().parent / "assets"
# LOGO_IMG = ASSET_DIR / "aiims_logo.png"

# FOOTER_LINES = [
#     ("For any assistance, contact: 1800-XXX-XXXX", 8),
#     ("Emergency: 24x7 | Ambulance: 108", 7),
#     ("Pharmacy: Ground Floor, Near OPD", 7),
#     ("Follow us on: www.aiims.edu", 6.5),
# ]

# LEFT_MARGIN = 12 * mm
# RIGHT_MARGIN = PAGE_W - 12 * mm
# BOTTOM_MARGIN = 34 * mm

# LEFT_COL_W = 38 * mm
# RIGHT_COL_X = LEFT_MARGIN + LEFT_COL_W + 4 * mm

# FONT_NAME = "Helvetica"
# FONT_BOLD = "Helvetica-Bold"
# FONT_ITALIC = "Helvetica-Oblique"


# def _clean(v: str | None) -> str:
#     return str(v).strip() if v is not None else ""


# def _safe_get(lines: List[str], prefix: str) -> str:
#     for line in lines:
#         if line.lower().startswith(prefix.lower()):
#             parts = line.split(":", 1)
#             return parts[1].strip() if len(parts) > 1 else ""
#     return ""


# def _is_section_header(line: str) -> str | None:
#     low = line.lower().strip()
#     mapping = {
#         "vitals:": "Vitals",
#         "medications:": "Prescription",
#         "investigations:": "Investigations",
#         "advice:": "Advice",
#         "referrals:": "Referrals",
#         "follow-up:": "Follow-up",
#         "drug warnings:": "Warnings",
#         "return immediately if:": "Warnings",
#     }
#     for k, v in mapping.items():
#         if low.startswith(k):
#             return v
#     return None


# def _extract_inline_value(line: str) -> str:
#     return line.split(":", 1)[1].strip() if ":" in line else ""


# def _normalize_bullet_text(text: str) -> str:
#     text = text.strip()
#     text = re.sub(r"^[-•\s]+", "", text)
#     return text.strip()


# def _parse_prescription_text(text: str) -> Dict[str, Any]:
#     if not text:
#         return {
#             "patient_name": "",
#             "age": "",
#             "sex": "",
#             "uhid": "",
#             "doctor_name": "",
#             "doctor_dept": "",
#             "doctor_reg": "",
#             "diagnosis": "",
#             "date": "",
#             "left_notes": [],
#             "sections": {},
#         }

#     lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]

#     data: Dict[str, Any] = {
#         "patient_name": "",
#         "age": "",
#         "sex": "",
#         "uhid": "",
#         "doctor_name": "",
#         "doctor_dept": "",
#         "doctor_reg": "",
#         "diagnosis": "",
#         "date": "",
#         "left_notes": [],
#         "sections": {},
#     }

#     patient_line = next((ln for ln in lines if ln.lower().startswith("patient:")), "")
#     if patient_line:
#         patient_text = patient_line.split(":", 1)[1].strip() if ":" in patient_line else ""
#         if "| age/sex:" in patient_text.lower():
#             parts = re.split(r"\|\s*age/sex\s*:", patient_text, flags=re.I)
#             if len(parts) == 2:
#                 data["patient_name"] = parts[0].strip()
#                 age_sex = parts[1].strip().split()
#                 if age_sex:
#                     data["age"] = age_sex[0]
#                     data["sex"] = " ".join(age_sex[1:]) if len(age_sex) > 1 else ""
#         else:
#             data["patient_name"] = patient_text

#     data["uhid"] = _safe_get(lines, "UHID")
#     data["doctor_name"] = _safe_get(lines, "Doctor")
#     data["doctor_dept"] = _safe_get(lines, "Department")
#     data["doctor_reg"] = _safe_get(lines, "Registration") or _safe_get(lines, "Reg No")
#     data["date"] = _safe_get(lines, "Date")
#     data["diagnosis"] = _safe_get(lines, "Diagnosis")

#     if not data["date"]:
#         date_match = re.search(r"(\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b)", text)
#         if date_match:
#             data["date"] = date_match.group(1)

#     left_notes: List[str] = []
#     for label, display in [
#         ("Allergies", "Allergies"),
#         ("Known conditions", "Conditions"),
#         ("Complaints", "Complaints"),
#         ("History", "History"),
#         ("Exam", "Exam"),
#     ]:
#         val = _safe_get(lines, label)
#         if val:
#             left_notes.append(f"{display}: {val}")
#     data["left_notes"] = left_notes

#     sections: Dict[str, List[str]] = {
#         "Vitals": [],
#         "Prescription": [],
#         "Investigations": [],
#         "Advice": [],
#         "Referrals": [],
#         "Follow-up": [],
#         "Warnings": [],
#     }

#     current_section = None
#     skip_prefixes = [
#         "patient:",
#         "uhid:",
#         "doctor:",
#         "department:",
#         "registration:",
#         "reg no:",
#         "date:",
#         "diagnosis:",
#         "allergies:",
#         "known conditions:",
#         "complaints:",
#         "history:",
#         "exam:",
#     ]

#     for ln in lines:
#         low = ln.lower().strip()
#         section_name = _is_section_header(ln)

#         if section_name:
#             inline_val = _extract_inline_value(ln)
#             if inline_val:
#                 sections[section_name].append(_normalize_bullet_text(inline_val))
#             current_section = section_name
#             continue

#         if any(low.startswith(p) for p in skip_prefixes):
#             current_section = None
#             continue

#         if current_section:
#             sections[current_section].append(_normalize_bullet_text(ln.strip()))

#     cleaned_sections: Dict[str, List[str]] = {}
#     for sec, items in sections.items():
#         unique_items, seen = [], set()
#         for item in items:
#             norm = re.sub(r"\s+", " ", item.strip().lower())
#             if norm and norm not in seen:
#                 seen.add(norm)
#                 unique_items.append(item.strip())
#         if unique_items:
#             cleaned_sections[sec] = unique_items

#     data["sections"] = cleaned_sections
#     return data



# def _draw_logo_proportional(
#     c: canvas.Canvas,
#     image_path: Path,
#     x: float,
#     y_top: float,
#     max_w: float,
#     max_h: float,
# ) -> None:
#     if not image_path.exists():
#         return

#     try:
#         img = ImageReader(str(image_path))
#         img_w, img_h = img.getSize()

#         if not img_w or not img_h:
#             return

#         scale = min(max_w / img_w, max_h / img_h)
#         draw_w = img_w * scale
#         draw_h = img_h * scale

#         # place inside box without distortion
#         draw_x = x + (max_w - draw_w) / 2
#         draw_y = y_top - draw_h

#         c.drawImage(
#             str(image_path),
#             draw_x,
#             draw_y,
#             width=draw_w,
#             height=draw_h,
#             mask="auto",
#             preserveAspectRatio=True,
#             anchor="c",
#         )
#     except Exception:
#         pass



# def _draw_header(c: canvas.Canvas, info: Dict[str, Any], page_num: int, total_pages: int) -> float:
#     left = LEFT_MARGIN
#     right = RIGHT_MARGIN
#     top = PAGE_H - 10 * mm

#     # proportional logo box
#     logo_box_w = 54 * mm
#     logo_box_h = 60 * mm
#     _draw_logo_proportional(
#         c,
#         LOGO_IMG,
#         x=left - 8 * mm,
#         y_top=top,
#         max_w=logo_box_w,
#         max_h=logo_box_h,
#     )

#     c.setFillColor(BLUE)
#     c.setFont(FONT_BOLD, 16)
#     c.drawCentredString(PAGE_W / 2, top - 6 * mm, "A.I.I.M.S. HOSPITAL")

#     c.setFont(FONT_BOLD, 12)
#     c.drawCentredString(PAGE_W / 2, top - 12 * mm, "Out Patient Department")

#     c.setFont(FONT_NAME, 7.5)
#     c.drawCentredString(PAGE_W / 2, top - 17 * mm, "SMOKING IS PROHIBITED IN HOSPITAL PREMISES")

#     if total_pages > 1:
#         c.setFillColor(colors.black)
#         c.setFont(FONT_NAME, 8)
#         c.drawRightString(right - 2 * mm, top - 12 * mm, f"Page {page_num} of {total_pages}")

#     box_top = top - 22 * mm
#     box_bottom = top - 46 * mm

#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.7)
#     c.line(left, box_top, right, box_top)
#     c.line(left, box_bottom, right, box_bottom)
#     c.line(left, box_top, left, box_bottom)
#     c.line(right, box_top, right, box_bottom)

#     v1, v2, v3 = left + 72 * mm, left + 102 * mm, left + 136 * mm
#     for x in (v1, v2, v3):
#         c.line(x, box_top, x, box_bottom)

#     c.setFillColor(BLUE)
#     c.setFont(FONT_NAME, 7)
#     c.drawString(left + 2 * mm, box_top - 3.5 * mm, "Name")
#     c.drawString(v1 + 2 * mm, box_top - 3.5 * mm, "UHID")
#     c.drawString(v2 + 2 * mm, box_top - 3.5 * mm, "Age / Sex")
#     c.drawString(v3 + 2 * mm, box_top - 3.5 * mm, "Doctor / Dept.")

#     c.setFillColor(colors.black)
#     c.setFont(FONT_BOLD, 10)
#     c.drawString(left + 2 * mm, box_top - 11 * mm, _clean(info.get("patient_name"))[:34])

#     c.setFont(FONT_NAME, 9)
#     c.drawString(v1 + 2 * mm, box_top - 11 * mm, _clean(info.get("uhid"))[:16])
#     c.drawString(v2 + 2 * mm, box_top - 11 * mm, f"{_clean(info.get('age'))} {_clean(info.get('sex'))}".strip())
#     c.drawString(v3 + 2 * mm, box_top - 10 * mm, (_clean(info.get("doctor_name")) or "Consulting Doctor")[:24])

#     if _clean(info.get("doctor_dept")):
#         c.drawString(v3 + 2 * mm, box_top - 15 * mm, _clean(info.get("doctor_dept"))[:26])

#     if _clean(info.get("doctor_reg")):
#         c.setFont(FONT_NAME, 7.5)
#         c.drawRightString(right - 2 * mm, box_bottom + 1.8 * mm, f"Reg: {_clean(info.get('doctor_reg'))}")

#     return box_bottom


# def _draw_diagnosis_strip(c: canvas.Canvas, info: Dict[str, Any], y_top: float) -> float:
#     left = LEFT_MARGIN
#     right = RIGHT_MARGIN
#     height = 18 * mm
#     y_bottom = y_top - height

#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.8)
#     c.rect(left, y_bottom, right - left, height)

#     date_split = right - 48 * mm
#     c.line(date_split, y_bottom, date_split, y_top)

#     # field labels
#     c.setFillColor(BLUE)
#     c.setFont(FONT_NAME, 7.5)
#     c.drawString(left + 2 * mm, y_top - 3.8 * mm, "Diagnosis")
#     c.drawString(date_split + 2 * mm, y_top - 3.8 * mm, "Date")

#     # main values
#     c.setFillColor(colors.black)
#     c.setFont(FONT_BOLD, 11)

#     diagnosis = _clean(info.get("diagnosis")) or " "
#     diagnosis_lines = wrap(diagnosis, width=60)[:2]

#     text_y = y_top - 9.5 * mm
#     for i, part in enumerate(diagnosis_lines):
#         c.drawString(left + 2 * mm, text_y - (i * 4.5 * mm), part)

#     c.setFont(FONT_NAME, 10.5)
#     c.drawString(date_split + 2 * mm, y_top - 10 * mm, _clean(info.get("date")))

#     return y_bottom


# def _draw_footer(c: canvas.Canvas) -> None:
#     left = LEFT_MARGIN
#     right = RIGHT_MARGIN
#     footer_y = 18 * mm

#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.5)
#     c.line(left, footer_y + 2 * mm, right, footer_y + 2 * mm)

#     c.setFillColor(BLUE)
#     current_y = footer_y
#     for text, font_size in FOOTER_LINES:
#         c.setFont(FONT_NAME, font_size)
#         c.drawCentredString(PAGE_W / 2, current_y, text)
#         current_y -= 3.5 * mm

#     c.setFont(FONT_BOLD, 8)
#     c.drawCentredString(PAGE_W / 2, current_y - 2 * mm, "CLEAN AND GREEN AIIMS | ORGAN DONATION - A GIFT OF LIFE")


# def _wrap_by_width(text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
#     text = text.strip()
#     if not text:
#         return [""]

#     words = text.split()
#     lines: List[str] = []
#     current = ""

#     for word in words:
#         trial = word if not current else f"{current} {word}"
#         if stringWidth(trial, font_name, font_size) <= max_width:
#             current = trial
#         else:
#             if current:
#                 lines.append(current)
#             current = word

#     if current:
#         lines.append(current)

#     return lines or [""]


# def _build_right_flow_lines(sections: Dict[str, List[str]], right_width: float) -> List[Dict[str, Any]]:
#     flow: List[Dict[str, Any]] = []
#     section_order = ["Vitals", "Prescription", "Investigations", "Advice", "Referrals", "Follow-up", "Warnings"]

#     for title in section_order:
#         if title not in sections:
#             continue

#         flow.append({"kind": "section", "text": title})

#         for item in sections[title]:
#             item = item.strip()
#             if not item:
#                 continue

#             if title == "Prescription" and re.match(r"^\d+\.", item):
#                 wrapped = _wrap_by_width(item, FONT_NAME, 9.2, right_width)
#             else:
#                 bullet_text = f"- {item}"
#                 wrapped = _wrap_by_width(bullet_text, FONT_NAME, 9.2, right_width)

#             for ln in wrapped:
#                 flow.append({"kind": "line", "text": ln})

#         flow.append({"kind": "gap", "text": ""})

#     while flow and flow[-1]["kind"] == "gap":
#         flow.pop()

#     return flow


# def _build_left_note_lines(left_notes: List[str], left_width: float, date_text: str) -> List[str]:
#     lines: List[str] = []

#     if date_text:
#         lines.append(date_text)
#         lines.append("")

#     for note in left_notes:
#         note = note.strip()
#         if ":" in note:
#             label, value = note.split(":", 1)
#             label = label.strip()
#             value = value.strip()

#             first_line = f"{label}: {value}"
#             wrapped = _wrap_by_width(first_line, FONT_NAME, 9, left_width)
#             lines.extend(wrapped)
#         else:
#             wrapped = _wrap_by_width(note, FONT_NAME, 9, left_width)
#             lines.extend(wrapped)

#         lines.append("")

#     while lines and lines[-1] == "":
#         lines.pop()

#     return lines


# def _paginate_flow(
#     right_flow: List[Dict[str, Any]],
#     left_lines: List[str],
#     first_page_body_top: float,
#     next_page_body_top: float,
#     body_bottom: float,
# ) -> List[Dict[str, Any]]:
#     pages: List[Dict[str, Any]] = []

#     right_line_h = 4.4 * mm
#     section_gap_h = 2.2 * mm
#     title_h = 5.0 * mm
#     left_line_h = 4.5 * mm

#     idx = 0
#     page_no = 0

#     while idx < len(right_flow) or page_no == 0:
#         page_no += 1
#         body_top = first_page_body_top if page_no == 1 else next_page_body_top
#         usable_h = body_top - body_bottom - 7 * mm

#         used = 0.0
#         page_items: List[Dict[str, Any]] = []

#         while idx < len(right_flow):
#             item = right_flow[idx]

#             if item["kind"] == "section":
#                 need = title_h
#             elif item["kind"] == "gap":
#                 need = section_gap_h
#             else:
#                 need = right_line_h

#             if used + need > usable_h and page_items:
#                 break

#             if item["kind"] == "section" and page_items:
#                 next_need = title_h + right_line_h
#                 if used + next_need > usable_h:
#                     break

#             page_items.append(item)
#             used += need
#             idx += 1

#         if page_no == 1:
#             max_left_lines = max(int(usable_h // left_line_h), 0)
#             page_left_lines = left_lines[:max_left_lines]
#         else:
#             page_left_lines = []

#         pages.append(
#             {
#                 "right_flow": page_items,
#                 "left_lines": page_left_lines,
#             }
#         )

#         if idx >= len(right_flow):
#             break

#     if not pages:
#         pages.append({"right_flow": [], "left_lines": left_lines})

#     return pages


# def _draw_body_page(c: canvas.Canvas, page_payload: Dict[str, Any], y_top: float) -> float:
#     left = LEFT_MARGIN
#     right = RIGHT_MARGIN
#     bottom = BOTTOM_MARGIN
#     left_w = LEFT_COL_W
#     right_x = RIGHT_COL_X

#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.8)
#     c.rect(left, bottom, right - left, y_top - bottom)
#     c.line(left + left_w, bottom, left + left_w, y_top)

#     # headers in blue
#     c.setFillColor(BLUE)
#     c.setFont(FONT_NAME, 7.5)
#     c.drawString(left + 2 * mm, y_top - 4.5 * mm, "Date / Notes")
#     c.drawString(left + left_w + 2 * mm, y_top - 4.5 * mm, "Prescription / Vitals / Treatment / Advice")

#     # LEFT COLUMN CONTENT -> BLACK
#     lx = left + 2.5 * mm
#     ly = y_top - 10 * mm

#     c.setFillColor(colors.black)

#     for i, line in enumerate(page_payload.get("left_lines", [])):
#         if ly < bottom + 6 * mm:
#             break

#         stripped = line.strip()

#         # date
#         if i == 0 and re.match(r"^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$", stripped):
#             c.setFillColor(colors.black)
#             c.setFont(FONT_BOLD, 10)
#             c.drawString(lx, ly, stripped)
#             ly -= 4.5 * mm
#             continue

#         # blank line
#         if not stripped:
#             ly -= 3.0 * mm
#             continue

#         # labeled notes like History: / Exam:
#         if ":" in stripped:
#             label, value = stripped.split(":", 1)
#             label = label.strip()
#             value = value.strip()

#             # label in blue
#             c.setFillColor(BLUE)
#             c.setFont(FONT_NAME, 9)
#             c.drawString(lx, ly, f"{label}:")

#             # value in black, slightly after label
#             label_w = stringWidth(f"{label}: ", FONT_NAME, 9)
#             c.setFillColor(colors.black)
#             c.drawString(lx + label_w, ly, value)
#         else:
#             c.setFillColor(colors.black)
#             c.setFont(FONT_NAME, 9)
#             c.drawString(lx, ly, stripped)

#         ly -= 4.5 * mm

#     # RIGHT COLUMN CONTENT
#     rx = right_x
#     ry = y_top - 8 * mm

#     for item in page_payload.get("right_flow", []):
#         kind = item["kind"]
#         text = item["text"]

#         if kind == "section":
#             c.setFont(FONT_BOLD, 10)
#             c.setFillColor(BLUE)   # section labels blue
#             c.drawString(rx, ry, text)
#             ry -= 5.0 * mm

#         elif kind == "gap":
#             ry -= 2.2 * mm

#         else:
#             c.setFont(FONT_NAME, 9.2)
#             c.setFillColor(colors.black)   # actual content black
#             c.drawString(rx, ry, text)
#             ry -= 4.4 * mm

#     return bottom


# def prescription_text_to_pdf(treatment_text: str) -> bytes:
#     buffer = BytesIO()

#     try:
#         c = canvas.Canvas(buffer, pagesize=A4)
#         c.setTitle("Medical Prescription")

#         info = _parse_prescription_text(treatment_text)

#         if not info.get("date"):
#             info["date"] = datetime.now().strftime("%d/%m/%Y")

#         header_bottom = PAGE_H - 56 * mm
#         diag_bottom = header_bottom - 4 * mm - 14 * mm

#         body_top = diag_bottom
#         body_bottom = BOTTOM_MARGIN

#         left_text_width = LEFT_COL_W - 5 * mm
#         right_text_width = RIGHT_MARGIN - RIGHT_COL_X - 4 * mm

#         right_flow = _build_right_flow_lines(info.get("sections", {}), right_text_width)
#         left_lines = _build_left_note_lines(info.get("left_notes", []), left_text_width, info.get("date", ""))

#         pages_payload = _paginate_flow(
#             right_flow=right_flow,
#             left_lines=left_lines,
#             first_page_body_top=body_top,
#             next_page_body_top=body_top,
#             body_bottom=body_bottom,
#         )

#         total_pages = len(pages_payload)

#         for page_num, page_payload in enumerate(pages_payload, 1):
#             header_bottom = _draw_header(c, info, page_num, total_pages)
#             diag_bottom = _draw_diagnosis_strip(c, info, header_bottom - 4 * mm)
#             _draw_body_page(c, page_payload, diag_bottom)
#             _draw_footer(c)

#             if page_num < total_pages:
#                 c.showPage()

#         c.save()

#     except Exception as e:
#         buffer = BytesIO()
#         c = canvas.Canvas(buffer, pagesize=A4)
#         c.setFont(FONT_NAME, 12)
#         c.drawString(20 * mm, PAGE_H / 2, f"Error generating prescription: {str(e)}")
#         c.save()

#     buffer.seek(0)
#     return buffer.read()










# from __future__ import annotations

# from io import BytesIO
# from pathlib import Path
# import re
# from datetime import datetime
# from typing import Dict, List, Any

# from textwrap import wrap
# from reportlab.lib import colors
# from reportlab.lib.pagesizes import A4
# from reportlab.lib.units import mm
# from reportlab.pdfgen import canvas
# from reportlab.pdfbase.pdfmetrics import stringWidth
# from reportlab.lib.utils import ImageReader

# PAGE_W, PAGE_H = A4

# BLUE = colors.HexColor("#1a2ea6")
# BLACK = colors.black
# LIGHT_BLUE = colors.HexColor("#dfe8ff")

# ASSET_DIR = Path(__file__).resolve().parent / "assets"
# LOGO_IMG = ASSET_DIR / "aiims_logo.png"

# LEFT = 14 * mm
# RIGHT = PAGE_W - 14 * mm
# TOP = PAGE_H - 12 * mm
# BOTTOM = 16 * mm

# FONT = "Helvetica"
# FONT_BOLD = "Helvetica-Bold"


# def _clean(v: Any) -> str:
#     return str(v).strip() if v is not None else ""


# def _safe_get(lines: List[str], prefix: str) -> str:
#     for line in lines:
#         if line.lower().startswith(prefix.lower()):
#             parts = line.split(":", 1)
#             return parts[1].strip() if len(parts) > 1 else ""
#     return ""


# def _normalize_bullet_text(text: str) -> str:
#     text = text.strip()
#     text = re.sub(r"^[-•\s]+", "", text)
#     return text.strip()


# def _extract_inline_value(line: str) -> str:
#     return line.split(":", 1)[1].strip() if ":" in line else ""


# def _is_section_header(line: str) -> str | None:
#     low = line.lower().strip()
#     mapping = {
#         "vitals:": "Vitals",
#         "medications:": "Rx",
#         "investigations:": "Investigations",
#         "advice:": "Advice",
#         "referrals:": "Referrals",
#         "follow-up:": "Follow-up",
#         "drug warnings:": "Warnings",
#         "return immediately if:": "Warnings",
#     }
#     for k, v in mapping.items():
#         if low.startswith(k):
#             return v
#     return None


# def _parse_prescription_text(text: str) -> Dict[str, Any]:
#     if not text:
#         return {
#             "patient_name": "",
#             "age": "",
#             "sex": "",
#             "uhid": "",
#             "doctor_name": "",
#             "doctor_dept": "",
#             "doctor_reg": "",
#             "diagnosis": "",
#             "date": "",
#             "complaints": "",
#             "history": "",
#             "exam": "",
#             "allergies": "",
#             "conditions": "",
#             "sections": {},
#         }

#     lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]

#     data: Dict[str, Any] = {
#         "patient_name": "",
#         "age": "",
#         "sex": "",
#         "uhid": "",
#         "doctor_name": "",
#         "doctor_dept": "",
#         "doctor_reg": "",
#         "diagnosis": "",
#         "date": "",
#         "complaints": "",
#         "history": "",
#         "exam": "",
#         "allergies": "",
#         "conditions": "",
#         "sections": {},
#     }

#     patient_line = next((ln for ln in lines if ln.lower().startswith("patient:")), "")
#     if patient_line:
#         patient_text = patient_line.split(":", 1)[1].strip() if ":" in patient_line else ""
#         if "| age/sex:" in patient_text.lower():
#             parts = re.split(r"\|\s*age/sex\s*:", patient_text, flags=re.I)
#             if len(parts) == 2:
#                 data["patient_name"] = parts[0].strip()
#                 age_sex = parts[1].strip().split()
#                 if age_sex:
#                     data["age"] = age_sex[0]
#                     data["sex"] = " ".join(age_sex[1:]) if len(age_sex) > 1 else ""
#         else:
#             data["patient_name"] = patient_text

#     data["uhid"] = _safe_get(lines, "UHID")
#     data["doctor_name"] = _safe_get(lines, "Doctor")
#     data["doctor_dept"] = _safe_get(lines, "Department")
#     data["doctor_reg"] = _safe_get(lines, "Registration") or _safe_get(lines, "Reg No")
#     data["date"] = _safe_get(lines, "Date")
#     data["diagnosis"] = _safe_get(lines, "Diagnosis")
#     data["complaints"] = _safe_get(lines, "Complaints")
#     data["history"] = _safe_get(lines, "History")
#     data["exam"] = _safe_get(lines, "Exam")
#     data["allergies"] = _safe_get(lines, "Allergies")
#     data["conditions"] = _safe_get(lines, "Known conditions")

#     if not data["date"]:
#         date_match = re.search(r"(\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b)", text)
#         if date_match:
#             data["date"] = date_match.group(1)

#     sections: Dict[str, List[str]] = {
#         "Vitals": [],
#         "Rx": [],
#         "Investigations": [],
#         "Advice": [],
#         "Referrals": [],
#         "Follow-up": [],
#         "Warnings": [],
#     }

#     current_section = None
#     skip_prefixes = [
#         "patient:",
#         "uhid:",
#         "doctor:",
#         "department:",
#         "registration:",
#         "reg no:",
#         "date:",
#         "diagnosis:",
#         "allergies:",
#         "known conditions:",
#         "complaints:",
#         "history:",
#         "exam:",
#     ]

#     for ln in lines:
#         low = ln.lower().strip()
#         section_name = _is_section_header(ln)

#         if section_name:
#             inline_val = _extract_inline_value(ln)
#             if inline_val:
#                 sections[section_name].append(_normalize_bullet_text(inline_val))
#             current_section = section_name
#             continue

#         if any(low.startswith(p) for p in skip_prefixes):
#             current_section = None
#             continue

#         if current_section:
#             sections[current_section].append(_normalize_bullet_text(ln.strip()))

#     cleaned_sections: Dict[str, List[str]] = {}
#     for sec, items in sections.items():
#         unique_items, seen = [], set()
#         for item in items:
#             norm = re.sub(r"\s+", " ", item.strip().lower())
#             if norm and norm not in seen:
#                 seen.add(norm)
#                 unique_items.append(item.strip())
#         if unique_items:
#             cleaned_sections[sec] = unique_items

#     data["sections"] = cleaned_sections
#     return data


# def _draw_logo_proportional(
#     c: canvas.Canvas,
#     image_path: Path,
#     x: float,
#     y_top: float,
#     max_w: float,
#     max_h: float,
# ) -> None:
#     if not image_path.exists():
#         return
#     try:
#         img = ImageReader(str(image_path))
#         img_w, img_h = img.getSize()
#         if not img_w or not img_h:
#             return

#         scale = min(max_w / img_w, max_h / img_h)
#         draw_w = img_w * scale
#         draw_h = img_h * scale

#         draw_x = x + (max_w - draw_w) / 2
#         draw_y = y_top - draw_h

#         c.drawImage(
#             str(image_path),
#             draw_x,
#             draw_y,
#             width=draw_w,
#             height=draw_h,
#             mask="auto",
#             preserveAspectRatio=True,
#             anchor="c",
#         )
#     except Exception:
#         pass


# def _wrap_by_width(text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
#     text = text.strip()
#     if not text:
#         return [""]

#     words = text.split()
#     lines: List[str] = []
#     current = ""

#     for word in words:
#         trial = word if not current else f"{current} {word}"
#         if stringWidth(trial, font_name, font_size) <= max_width:
#             current = trial
#         else:
#             if current:
#                 lines.append(current)
#             current = word

#     if current:
#         lines.append(current)

#     return lines or [""]


# def _draw_header(c: canvas.Canvas, info: Dict[str, Any], page_num: int, total_pages: int) -> float:
#     y = TOP

#     _draw_logo_proportional(
#         c,
#         LOGO_IMG,
#         x=LEFT - 4 * mm,
#         y_top=y,
#         max_w=26 * mm,
#         max_h=28 * mm,
#     )

#     c.setFillColor(BLUE)
#     c.setFont(FONT_BOLD, 20)
#     c.drawCentredString(PAGE_W / 2, y - 6 * mm, "A.I.I.M.S. HOSPITAL")

#     c.setFont(FONT_BOLD, 13)
#     c.drawCentredString(PAGE_W / 2, y - 13 * mm, "Out Patient Department")

#     c.setFont(FONT, 8.5)
#     c.drawCentredString(PAGE_W / 2, y - 19 * mm, "SMOKING IS PROHIBITED IN HOSPITAL PREMISES")

#     if total_pages > 1:
#         c.setFillColor(BLACK)
#         c.setFont(FONT, 8)
#         c.drawRightString(RIGHT, y - 13 * mm, f"Page {page_num} of {total_pages}")

#     line_y = y - 25 * mm
#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.9)
#     c.line(LEFT, line_y, RIGHT, line_y)

#     return line_y - 5 * mm


# def _draw_top_info_block(c: canvas.Canvas, info: Dict[str, Any], y_top: float) -> float:
#     box_h = 26 * mm
#     y_bottom = y_top - box_h

#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.8)
#     c.rect(LEFT, y_bottom, RIGHT - LEFT, box_h)

#     split1 = LEFT + 112 * mm
#     split2 = RIGHT - 32 * mm

#     c.line(split1, y_bottom, split1, y_top)
#     c.line(split2, y_bottom, split2, y_top)

#     c.setFillColor(BLUE)
#     c.setFont(FONT, 7.5)
#     c.drawString(LEFT + 2 * mm, y_top - 4 * mm, "Patient")
#     c.drawString(split1 + 2 * mm, y_top - 4 * mm, "Diagnosis")
#     c.drawString(split2 + 2 * mm, y_top - 4 * mm, "Date")

#     c.setFillColor(BLACK)
#     c.setFont(FONT_BOLD, 11)

#     patient_line = _clean(info.get("patient_name"))
#     age_sex = " ".join([_clean(info.get("age")), _clean(info.get("sex"))]).strip()
#     if age_sex:
#         patient_line = f"{patient_line} ({age_sex})"

#     patient_lines = _wrap_by_width(patient_line, FONT_BOLD, 11, (split1 - LEFT) - 4 * mm)
#     py = y_top - 10 * mm
#     for part in patient_lines[:2]:
#         c.drawString(LEFT + 2 * mm, py, part)
#         py -= 4.8 * mm

#     c.setFont(FONT, 9)
#     uhid = _clean(info.get("uhid"))
#     doctor_name = _clean(info.get("doctor_name")) or "Consulting Doctor"
#     doctor_dept = _clean(info.get("doctor_dept"))
#     doctor_reg = _clean(info.get("doctor_reg"))

#     info_line = ""
#     if uhid:
#         info_line += f"UHID: {uhid}"
#     if doctor_name:
#         if info_line:
#             info_line += " | "
#         info_line += doctor_name
#     if doctor_dept:
#         info_line += f" ({doctor_dept})"

#     info_lines = _wrap_by_width(info_line, FONT, 9, (split1 - LEFT) - 4 * mm)
#     iy = y_bottom + 6.5 * mm
#     for part in info_lines[:2]:
#         c.drawString(LEFT + 2 * mm, iy, part)
#         iy -= 4.2 * mm

#     if doctor_reg:
#         c.setFont(FONT, 8)
#         c.drawString(LEFT + 2 * mm, y_bottom + 2 * mm, f"Reg: {doctor_reg}")

#     c.setFont(FONT_BOLD, 10.5)
#     diagnosis = _clean(info.get("diagnosis")) or "-"
#     dx_lines = _wrap_by_width(diagnosis, FONT_BOLD, 10.5, (split2 - split1) - 4 * mm)
#     dy = y_top - 10 * mm
#     for part in dx_lines[:3]:
#         c.drawString(split1 + 2 * mm, dy, part)
#         dy -= 4.5 * mm

#     c.setFont(FONT, 10)
#     c.drawString(split2 + 2 * mm, y_top - 10 * mm, _clean(info.get("date")) or datetime.now().strftime("%d/%m/%Y"))

#     return y_bottom - 5 * mm


# def _build_body_flow(info: Dict[str, Any], width: float) -> List[Dict[str, str]]:
#     flow: List[Dict[str, str]] = []

#     def add_label_value(label: str, value: str, value_font_size: float = 10):
#         value = _clean(value)
#         if not value:
#             return
#         flow.append({"kind": "label", "text": label})
#         wrapped = _wrap_by_width(value, FONT, value_font_size, width)
#         for ln in wrapped:
#             flow.append({"kind": "text", "text": ln})
#         flow.append({"kind": "gap", "text": ""})

#     def add_section(title: str, items: List[str]):
#         if not items:
#             return
#         flow.append({"kind": "section", "text": title})
#         for item in items:
#             item = _clean(item)
#             if not item:
#                 continue
#             if title == "Rx":
#                 wrapped = _wrap_by_width(item, FONT, 10, width)
#                 for i, ln in enumerate(wrapped):
#                     flow.append({"kind": "rx", "text": ln if i > 0 else ln})
#             elif title == "Advice":
#                 wrapped = _wrap_by_width(item, FONT, 10, width - 5 * mm)
#                 first = True
#                 for ln in wrapped:
#                     if first:
#                         flow.append({"kind": "advice", "text": ln})
#                         first = False
#                     else:
#                         flow.append({"kind": "advice_cont", "text": ln})
#             else:
#                 wrapped = _wrap_by_width(item, FONT, 10, width - 3 * mm)
#                 first = True
#                 for ln in wrapped:
#                     flow.append({"kind": "bullet" if first else "bullet_cont", "text": ln})
#                     first = False
#         flow.append({"kind": "gap", "text": ""})

#     add_label_value("Complaints", info.get("complaints", ""))
#     add_label_value("History", info.get("history", ""))
#     add_label_value("Sys.Exam", info.get("exam", ""))
#     add_label_value("Allergies", info.get("allergies", ""))
#     add_label_value("Known conditions", info.get("conditions", ""))

#     sections = info.get("sections", {})
#     if sections.get("Vitals"):
#         add_section("Vitals", sections["Vitals"])
#     if sections.get("Rx"):
#         add_section("Rx", sections["Rx"])
#     if sections.get("Investigations"):
#         add_section("Investigations", sections["Investigations"])
#     if sections.get("Advice"):
#         add_section("Advice", sections["Advice"])
#     if sections.get("Referrals"):
#         add_section("Referrals", sections["Referrals"])
#     if sections.get("Warnings"):
#         add_section("Warnings", sections["Warnings"])
#     if sections.get("Follow-up"):
#         add_section("Follow-up", sections["Follow-up"])

#     while flow and flow[-1]["kind"] == "gap":
#         flow.pop()

#     return flow


# def _paginate_body(flow: List[Dict[str, str]], y_top: float, y_bottom: float) -> List[List[Dict[str, str]]]:
#     pages: List[List[Dict[str, str]]] = []
#     page_items: List[Dict[str, str]] = []
#     used = 0.0
#     usable = y_top - y_bottom

#     def item_h(kind: str) -> float:
#         if kind == "section":
#             return 6.0 * mm
#         if kind == "label":
#             return 5.2 * mm
#         if kind == "gap":
#             return 2.0 * mm
#         return 4.8 * mm

#     for item in flow:
#         need = item_h(item["kind"])
#         if used + need > usable and page_items:
#             pages.append(page_items)
#             page_items = []
#             used = 0.0
#         page_items.append(item)
#         used += need

#     if page_items:
#         pages.append(page_items)

#     if not pages:
#         pages.append([])

#     return pages


# def _draw_body(c: canvas.Canvas, page_items: List[Dict[str, str]], y_top: float) -> None:
#     y = y_top
#     width = RIGHT - LEFT

#     for item in page_items:
#         kind = item["kind"]
#         text = item["text"]

#         if kind == "section":
#             c.setFillColor(BLUE)
#             c.setFont(FONT_BOLD, 12)
#             c.drawString(LEFT, y, text)
#             y -= 6.0 * mm

#         elif kind == "label":
#             c.setFillColor(BLUE)
#             c.setFont(FONT_BOLD, 10)
#             c.drawString(LEFT, y, f"{text}:")
#             y -= 5.2 * mm

#         elif kind == "text":
#             c.setFillColor(BLACK)
#             c.setFont(FONT, 10)
#             c.drawString(LEFT + 2 * mm, y, text)
#             y -= 4.8 * mm

#         elif kind == "rx":
#             c.setFillColor(BLACK)
#             c.setFont(FONT, 10)
#             c.drawString(LEFT + 3 * mm, y, text)
#             y -= 4.8 * mm

#         elif kind == "bullet":
#             c.setFillColor(BLACK)
#             c.setFont(FONT, 10)
#             c.drawString(LEFT + 2 * mm, y, u"\u2022")
#             c.drawString(LEFT + 6 * mm, y, text)
#             y -= 4.8 * mm

#         elif kind == "bullet_cont":
#             c.setFillColor(BLACK)
#             c.setFont(FONT, 10)
#             c.drawString(LEFT + 6 * mm, y, text)
#             y -= 4.8 * mm

#         elif kind == "advice":
#             c.setFillColor(BLACK)
#             c.setFont(FONT, 10)
#             c.drawString(LEFT + 2 * mm, y, u"\u2022")
#             c.drawString(LEFT + 6 * mm, y, text)
#             y -= 4.8 * mm

#         elif kind == "advice_cont":
#             c.setFillColor(BLACK)
#             c.setFont(FONT, 10)
#             c.drawString(LEFT + 6 * mm, y, text)
#             y -= 4.8 * mm

#         elif kind == "gap":
#             y -= 2.0 * mm

#     c.setStrokeColor(BLUE)
#     c.setLineWidth(0.5)
#     c.line(LEFT, BOTTOM + 6 * mm, RIGHT, BOTTOM + 6 * mm)

#     c.setFillColor(BLUE)
#     c.setFont(FONT, 7.5)
#     c.drawCentredString(PAGE_W / 2, BOTTOM + 2 * mm, "CLEAN AND GREEN AIIMS | ORGAN DONATION - A GIFT OF LIFE")


# def prescription_text_to_pdf(treatment_text: str) -> bytes:
#     buffer = BytesIO()

#     try:
#         info = _parse_prescription_text(treatment_text)
#         if not info.get("date"):
#             info["date"] = datetime.now().strftime("%d/%m/%Y")

#         c = canvas.Canvas(buffer, pagesize=A4)
#         c.setTitle("Medical Prescription")

#         first_top_after_header = _draw_header(c, info, 1, 1)
#         top_after_info = _draw_top_info_block(c, info, first_top_after_header)

#         flow_width = RIGHT - LEFT - 3 * mm
#         body_flow = _build_body_flow(info, flow_width)
#         page_bodies = _paginate_body(body_flow, top_after_info, BOTTOM + 10 * mm)

#         total_pages = max(1, len(page_bodies))

#         c = canvas.Canvas(buffer, pagesize=A4)
#         c.setTitle("Medical Prescription")

#         for idx, items in enumerate(page_bodies, 1):
#             y1 = _draw_header(c, info, idx, total_pages)
#             y2 = _draw_top_info_block(c, info, y1)
#             _draw_body(c, items, y2)

#             if idx < total_pages:
#                 c.showPage()

#         c.save()

#     except Exception as e:
#         buffer = BytesIO()
#         c = canvas.Canvas(buffer, pagesize=A4)
#         c.setFont(FONT, 12)
#         c.drawString(20 * mm, PAGE_H / 2, f"Error generating prescription: {str(e)}")
#         c.save()

#     buffer.seek(0)
#     return buffer.read()







from __future__ import annotations

from io import BytesIO
from pathlib import Path
import re
from datetime import datetime
from typing import Dict, List, Any

from textwrap import wrap
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.lib.utils import ImageReader

PAGE_W, PAGE_H = A4
BLUE = colors.HexColor("#3a92b8")
DARK = colors.HexColor("#1f2d3d")

ASSET_DIR = Path(__file__).resolve().parent / "assets"
LOGO_IMG = ASSET_DIR / "aiims_logo.png"

FOOTER_LINES = [
    ("For any assistance, contact: 1800-XXX-XXXX", 8),
    ("Emergency: 24x7 | Ambulance: 108", 7),
    ("Pharmacy: Ground Floor, Near OPD", 7),
    ("Follow us on: www.aiims.edu", 6.5),
]

LEFT_MARGIN = 12 * mm
RIGHT_MARGIN = PAGE_W - 12 * mm
BOTTOM_MARGIN = 34 * mm

LEFT_COL_W = 38 * mm
RIGHT_COL_X = LEFT_MARGIN + LEFT_COL_W + 4 * mm

FONT_NAME = "Helvetica"
FONT_BOLD = "Helvetica-Bold"
FONT_ITALIC = "Helvetica-Oblique"


def _clean(v: str | None) -> str:
    return str(v).strip() if v is not None else ""


def _safe_get(lines: List[str], prefix: str) -> str:
    for line in lines:
        if line.lower().startswith(prefix.lower()):
            parts = line.split(":", 1)
            return parts[1].strip() if len(parts) > 1 else ""
    return ""


def _is_section_header(line: str) -> str | None:
    low = line.lower().strip()
    mapping = {
        "vitals:": "Vitals",
        "medications:": "Prescription",
        "investigations:": "Investigations",
        "advice:": "Advice",
        "referrals:": "Referrals",
        "follow-up:": "Follow-up",
        "drug warnings:": "Warnings",
        "return immediately if:": "Warnings",
    }
    for k, v in mapping.items():
        if low.startswith(k):
            return v
    return None


def _extract_inline_value(line: str) -> str:
    return line.split(":", 1)[1].strip() if ":" in line else ""


def _normalize_bullet_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^[-•\s]+", "", text)
    return text.strip()


def _looks_like_meaningful_prescription_text(text: str) -> bool:
    t = _clean(text)
    if not t:
        return False

    # reject tiny / placeholder content
    stripped_lines = [ln.strip() for ln in t.splitlines() if ln.strip()]
    if not stripped_lines:
        return False

    joined = " ".join(stripped_lines).lower()

    # obvious empty placeholder cases
    if joined in {
        "patient:",
        "patient: | age/sex:",
        "patient: age/sex:",
        "medications:",
        "prescription:",
    }:
        return False

    # require some actual medical structure/content
    signals = 0

    if re.search(r"\bpatient\s*:", joined):
        signals += 1
    if re.search(r"\bdiagnosis\s*:", joined):
        signals += 1
    if re.search(r"\bhistory\s*:", joined):
        signals += 1
    if re.search(r"\bexam\s*:", joined):
        signals += 1
    if re.search(r"\bvitals\s*:", joined):
        signals += 1
    if re.search(r"\bmedications\s*:", joined):
        signals += 2
    if re.search(r"\bfollow[\s-]?up\s*:", joined):
        signals += 1
    if re.search(r"\bbp\s*[:0-9]", joined):
        signals += 1
    if re.search(r"\bpulse\s*[:0-9]", joined):
        signals += 1
    if re.search(r"\b\d+\.\s*[a-z]", joined):
        signals += 2
    if re.search(r"\bmg\b|\bml\b|\btablet\b|\bcapsule\b|\bsyrup\b|\binjection\b", joined):
        signals += 2

    # need at least some content beyond labels
    non_label_text = re.sub(
        r"\b(patient|age/sex|uhid|doctor|department|registration|reg no|date|diagnosis|allergies|known conditions|complaints|history|exam|vitals|medications|investigations|advice|referrals|follow-up|drug warnings|return immediately if)\s*:",
        " ",
        joined,
        flags=re.I,
    )
    non_label_text = re.sub(r"\s+", " ", non_label_text).strip()

    if len(non_label_text) < 8:
        return False

    return signals >= 2


def _parse_prescription_text(text: str) -> Dict[str, Any]:
    if not text:
        return {
            "patient_name": "",
            "age": "",
            "sex": "",
            "uhid": "",
            "doctor_name": "",
            "doctor_dept": "",
            "doctor_reg": "",
            "diagnosis": "",
            "date": "",
            "left_notes": [],
            "sections": {},
        }

    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]

    data: Dict[str, Any] = {
        "patient_name": "",
        "age": "",
        "sex": "",
        "uhid": "",
        "doctor_name": "",
        "doctor_dept": "",
        "doctor_reg": "",
        "diagnosis": "",
        "date": "",
        "left_notes": [],
        "sections": {},
    }

    patient_line = next((ln for ln in lines if ln.lower().startswith("patient:")), "")
    if patient_line:
        patient_text = patient_line.split(":", 1)[1].strip() if ":" in patient_line else ""
        if "| age/sex:" in patient_text.lower():
            parts = re.split(r"\|\s*age/sex\s*:", patient_text, flags=re.I)
            if len(parts) == 2:
                data["patient_name"] = parts[0].strip()
                age_sex = parts[1].strip().split()
                if age_sex:
                    data["age"] = age_sex[0]
                    data["sex"] = " ".join(age_sex[1:]) if len(age_sex) > 1 else ""
        else:
            data["patient_name"] = patient_text

    data["uhid"] = _safe_get(lines, "UHID")
    data["doctor_name"] = _safe_get(lines, "Doctor")
    data["doctor_dept"] = _safe_get(lines, "Department")
    data["doctor_reg"] = _safe_get(lines, "Registration") or _safe_get(lines, "Reg No")
    data["date"] = _safe_get(lines, "Date")
    data["diagnosis"] = _safe_get(lines, "Diagnosis")

    if not data["date"]:
        date_match = re.search(r"(\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b)", text)
        if date_match:
            data["date"] = date_match.group(1)

    left_notes: List[str] = []
    for label, display in [
        ("Allergies", "Allergies"),
        ("Known conditions", "Conditions"),
        ("Complaints", "Complaints"),
        ("History", "History"),
        ("Exam", "Exam"),
    ]:
        val = _safe_get(lines, label)
        if val:
            left_notes.append(f"{display}: {val}")
    data["left_notes"] = left_notes

    sections: Dict[str, List[str]] = {
        "Vitals": [],
        "Prescription": [],
        "Investigations": [],
        "Advice": [],
        "Referrals": [],
        "Follow-up": [],
        "Warnings": [],
    }

    current_section = None
    skip_prefixes = [
        "patient:",
        "uhid:",
        "doctor:",
        "department:",
        "registration:",
        "reg no:",
        "date:",
        "diagnosis:",
        "allergies:",
        "known conditions:",
        "complaints:",
        "history:",
        "exam:",
    ]

    for ln in lines:
        low = ln.lower().strip()
        section_name = _is_section_header(ln)

        if section_name:
            inline_val = _extract_inline_value(ln)
            if inline_val:
                sections[section_name].append(_normalize_bullet_text(inline_val))
            current_section = section_name
            continue

        if any(low.startswith(p) for p in skip_prefixes):
            current_section = None
            continue

        if current_section:
            sections[current_section].append(_normalize_bullet_text(ln.strip()))

    cleaned_sections: Dict[str, List[str]] = {}
    for sec, items in sections.items():
        unique_items, seen = [], set()
        for item in items:
            norm = re.sub(r"\s+", " ", item.strip().lower())
            if norm and norm not in seen:
                seen.add(norm)
                unique_items.append(item.strip())
        if unique_items:
            cleaned_sections[sec] = unique_items

    data["sections"] = cleaned_sections
    return data


def _draw_logo_proportional(
    c: canvas.Canvas,
    image_path: Path,
    x: float,
    y_top: float,
    max_w: float,
    max_h: float,
) -> None:
    if not image_path.exists():
        return

    try:
        img = ImageReader(str(image_path))
        img_w, img_h = img.getSize()

        if not img_w or not img_h:
            return

        scale = min(max_w / img_w, max_h / img_h)
        draw_w = img_w * scale
        draw_h = img_h * scale

        draw_x = x + (max_w - draw_w) / 2
        draw_y = y_top - draw_h

        c.drawImage(
            str(image_path),
            draw_x,
            draw_y,
            width=draw_w,
            height=draw_h,
            mask="auto",
            preserveAspectRatio=True,
            anchor="c",
        )
    except Exception:
        pass


def _draw_header(c: canvas.Canvas, info: Dict[str, Any], page_num: int, total_pages: int) -> float:
    left = LEFT_MARGIN
    right = RIGHT_MARGIN
    top = PAGE_H - 10 * mm

    logo_box_w = 54 * mm
    logo_box_h = 60 * mm
    _draw_logo_proportional(
        c,
        LOGO_IMG,
        x=left - 8 * mm,
        y_top=top,
        max_w=logo_box_w,
        max_h=logo_box_h,
    )

    c.setFillColor(BLUE)
    c.setFont(FONT_BOLD, 16)
    c.drawCentredString(PAGE_W / 2, top - 6 * mm, "A.I.I.M.S. HOSPITAL")

    c.setFont(FONT_BOLD, 12)
    c.drawCentredString(PAGE_W / 2, top - 12 * mm, "Out Patient Department")

    c.setFont(FONT_NAME, 7.5)
    c.drawCentredString(PAGE_W / 2, top - 17 * mm, "SMOKING IS PROHIBITED IN HOSPITAL PREMISES")

    if total_pages > 1:
        c.setFillColor(colors.black)
        c.setFont(FONT_NAME, 8)
        c.drawRightString(right - 2 * mm, top - 12 * mm, f"Page {page_num} of {total_pages}")

    box_top = top - 22 * mm
    box_bottom = top - 46 * mm

    c.setStrokeColor(BLUE)
    c.setLineWidth(0.7)
    c.line(left, box_top, right, box_top)
    c.line(left, box_bottom, right, box_bottom)
    c.line(left, box_top, left, box_bottom)
    c.line(right, box_top, right, box_bottom)

    v1, v2, v3 = left + 72 * mm, left + 102 * mm, left + 136 * mm
    for x in (v1, v2, v3):
        c.line(x, box_top, x, box_bottom)

    c.setFillColor(BLUE)
    c.setFont(FONT_NAME, 7)
    c.drawString(left + 2 * mm, box_top - 3.5 * mm, "Name")
    c.drawString(v1 + 2 * mm, box_top - 3.5 * mm, "UHID")
    c.drawString(v2 + 2 * mm, box_top - 3.5 * mm, "Age / Sex")
    c.drawString(v3 + 2 * mm, box_top - 3.5 * mm, "Doctor / Dept.")

    c.setFillColor(colors.black)
    c.setFont(FONT_BOLD, 10)
    c.drawString(left + 2 * mm, box_top - 11 * mm, _clean(info.get("patient_name"))[:34])

    c.setFont(FONT_NAME, 9)
    c.drawString(v1 + 2 * mm, box_top - 11 * mm, _clean(info.get("uhid"))[:16])
    c.drawString(v2 + 2 * mm, box_top - 11 * mm, f"{_clean(info.get('age'))} {_clean(info.get('sex'))}".strip())
    c.drawString(v3 + 2 * mm, box_top - 10 * mm, (_clean(info.get("doctor_name")) or "Consulting Doctor")[:24])

    if _clean(info.get("doctor_dept")):
        c.drawString(v3 + 2 * mm, box_top - 15 * mm, _clean(info.get("doctor_dept"))[:26])

    if _clean(info.get("doctor_reg")):
        c.setFont(FONT_NAME, 7.5)
        c.drawRightString(right - 2 * mm, box_bottom + 1.8 * mm, f"Reg: {_clean(info.get('doctor_reg'))}")

    return box_bottom


def _draw_diagnosis_strip(c: canvas.Canvas, info: Dict[str, Any], y_top: float) -> float:
    left = LEFT_MARGIN
    right = RIGHT_MARGIN
    height = 18 * mm
    y_bottom = y_top - height

    c.setStrokeColor(BLUE)
    c.setLineWidth(0.8)
    c.rect(left, y_bottom, right - left, height)

    date_split = right - 48 * mm
    c.line(date_split, y_bottom, date_split, y_top)

    c.setFillColor(BLUE)
    c.setFont(FONT_NAME, 7.5)
    c.drawString(left + 2 * mm, y_top - 3.8 * mm, "Diagnosis")
    c.drawString(date_split + 2 * mm, y_top - 3.8 * mm, "Date")

    c.setFillColor(colors.black)
    c.setFont(FONT_BOLD, 11)

    diagnosis = _clean(info.get("diagnosis")) or " "
    diagnosis_lines = wrap(diagnosis, width=60)[:2]

    text_y = y_top - 9.5 * mm
    for i, part in enumerate(diagnosis_lines):
        c.drawString(left + 2 * mm, text_y - (i * 4.5 * mm), part)

    c.setFont(FONT_NAME, 10.5)
    c.drawString(date_split + 2 * mm, y_top - 10 * mm, _clean(info.get("date")))

    return y_bottom


def _draw_footer(c: canvas.Canvas) -> None:
    left = LEFT_MARGIN
    right = RIGHT_MARGIN
    footer_y = 18 * mm

    c.setStrokeColor(BLUE)
    c.setLineWidth(0.5)
    c.line(left, footer_y + 2 * mm, right, footer_y + 2 * mm)

    c.setFillColor(BLUE)
    current_y = footer_y
    for text, font_size in FOOTER_LINES:
        c.setFont(FONT_NAME, font_size)
        c.drawCentredString(PAGE_W / 2, current_y, text)
        current_y -= 3.5 * mm

    c.setFont(FONT_BOLD, 8)
    c.drawCentredString(PAGE_W / 2, current_y - 2 * mm, "CLEAN AND GREEN AIIMS | ORGAN DONATION - A GIFT OF LIFE")


def _wrap_by_width(text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
    text = text.strip()
    if not text:
        return [""]

    words = text.split()
    lines: List[str] = []
    current = ""

    for word in words:
        trial = word if not current else f"{current} {word}"
        if stringWidth(trial, font_name, font_size) <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word

    if current:
        lines.append(current)

    return lines or [""]


def _build_right_flow_lines(sections: Dict[str, List[str]], right_width: float) -> List[Dict[str, Any]]:
    flow: List[Dict[str, Any]] = []
    section_order = ["Vitals", "Prescription", "Investigations", "Advice", "Referrals", "Follow-up", "Warnings"]

    for title in section_order:
        if title not in sections:
            continue

        flow.append({"kind": "section", "text": title})

        for item in sections[title]:
            item = item.strip()
            if not item:
                continue

            if title == "Prescription" and re.match(r"^\d+\.", item):
                wrapped = _wrap_by_width(item, FONT_NAME, 9.2, right_width)
            else:
                bullet_text = f"- {item}"
                wrapped = _wrap_by_width(bullet_text, FONT_NAME, 9.2, right_width)

            for ln in wrapped:
                flow.append({"kind": "line", "text": ln})

        flow.append({"kind": "gap", "text": ""})

    while flow and flow[-1]["kind"] == "gap":
        flow.pop()

    return flow


def _build_left_note_lines(left_notes: List[str], left_width: float, date_text: str) -> List[str]:
    lines: List[str] = []

    if date_text:
        lines.append(date_text)
        lines.append("")

    for note in left_notes:
        note = note.strip()
        if ":" in note:
            label, value = note.split(":", 1)
            label = label.strip()
            value = value.strip()

            first_line = f"{label}: {value}"
            wrapped = _wrap_by_width(first_line, FONT_NAME, 9, left_width)
            lines.extend(wrapped)
        else:
            wrapped = _wrap_by_width(note, FONT_NAME, 9, left_width)
            lines.extend(wrapped)

        lines.append("")

    while lines and lines[-1] == "":
        lines.pop()

    return lines


def _paginate_flow(
    right_flow: List[Dict[str, Any]],
    left_lines: List[str],
    first_page_body_top: float,
    next_page_body_top: float,
    body_bottom: float,
) -> List[Dict[str, Any]]:
    pages: List[Dict[str, Any]] = []

    right_line_h = 4.4 * mm
    section_gap_h = 2.2 * mm
    title_h = 5.0 * mm
    left_line_h = 4.5 * mm

    idx = 0
    page_no = 0

    while idx < len(right_flow) or page_no == 0:
        page_no += 1
        body_top = first_page_body_top if page_no == 1 else next_page_body_top
        usable_h = body_top - body_bottom - 7 * mm

        used = 0.0
        page_items: List[Dict[str, Any]] = []

        while idx < len(right_flow):
            item = right_flow[idx]

            if item["kind"] == "section":
                need = title_h
            elif item["kind"] == "gap":
                need = section_gap_h
            else:
                need = right_line_h

            if used + need > usable_h and page_items:
                break

            if item["kind"] == "section" and page_items:
                next_need = title_h + right_line_h
                if used + next_need > usable_h:
                    break

            page_items.append(item)
            used += need
            idx += 1

        if page_no == 1:
            max_left_lines = max(int(usable_h // left_line_h), 0)
            page_left_lines = left_lines[:max_left_lines]
        else:
            page_left_lines = []

        pages.append(
            {
                "right_flow": page_items,
                "left_lines": page_left_lines,
            }
        )

        if idx >= len(right_flow):
            break

    if not pages:
        pages.append({"right_flow": [], "left_lines": left_lines})

    return pages


def _draw_body_page(c: canvas.Canvas, page_payload: Dict[str, Any], y_top: float) -> float:
    left = LEFT_MARGIN
    right = RIGHT_MARGIN
    bottom = BOTTOM_MARGIN
    left_w = LEFT_COL_W
    right_x = RIGHT_COL_X

    c.setStrokeColor(BLUE)
    c.setLineWidth(0.8)
    c.rect(left, bottom, right - left, y_top - bottom)
    c.line(left + left_w, bottom, left + left_w, y_top)

    c.setFillColor(BLUE)
    c.setFont(FONT_NAME, 7.5)
    c.drawString(left + 2 * mm, y_top - 4.5 * mm, "Date / Notes")
    c.drawString(left + left_w + 2 * mm, y_top - 4.5 * mm, "Prescription / Vitals / Treatment / Advice")

    lx = left + 2.5 * mm
    ly = y_top - 10 * mm

    c.setFillColor(colors.black)

    for i, line in enumerate(page_payload.get("left_lines", [])):
        if ly < bottom + 6 * mm:
            break

        stripped = line.strip()

        if i == 0 and re.match(r"^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$", stripped):
            c.setFillColor(colors.black)
            c.setFont(FONT_BOLD, 10)
            c.drawString(lx, ly, stripped)
            ly -= 4.5 * mm
            continue

        if not stripped:
            ly -= 3.0 * mm
            continue

        if ":" in stripped:
            label, value = stripped.split(":", 1)
            label = label.strip()
            value = value.strip()

            c.setFillColor(BLUE)
            c.setFont(FONT_NAME, 9)
            c.drawString(lx, ly, f"{label}:")

            label_w = stringWidth(f"{label}: ", FONT_NAME, 9)
            c.setFillColor(colors.black)
            c.drawString(lx + label_w, ly, value)
        else:
            c.setFillColor(colors.black)
            c.setFont(FONT_NAME, 9)
            c.drawString(lx, ly, stripped)

        ly -= 4.5 * mm

    rx = right_x
    ry = y_top - 8 * mm

    for item in page_payload.get("right_flow", []):
        kind = item["kind"]
        text = item["text"]

        if kind == "section":
            c.setFont(FONT_BOLD, 10)
            c.setFillColor(BLUE)
            c.drawString(rx, ry, text)
            ry -= 5.0 * mm

        elif kind == "gap":
            ry -= 2.2 * mm

        else:
            c.setFont(FONT_NAME, 9.2)
            c.setFillColor(colors.black)
            c.drawString(rx, ry, text)
            ry -= 4.4 * mm

    return bottom


def prescription_text_to_pdf(treatment_text: str) -> bytes:
    buffer = BytesIO()

    try:
        if not _looks_like_meaningful_prescription_text(treatment_text):
            c = canvas.Canvas(buffer, pagesize=A4)
            c.setTitle("Medical Prescription")
            c.setFont(FONT_BOLD, 13)
            c.drawString(20 * mm, PAGE_H / 2 + 4 * mm, "No valid prescription content detected.")
            c.setFont(FONT_NAME, 10)
            c.drawString(20 * mm, PAGE_H / 2 - 2 * mm, "Please retry with a valid medical dictation or prescription text.")
            c.save()
            buffer.seek(0)
            return buffer.read()

        c = canvas.Canvas(buffer, pagesize=A4)
        c.setTitle("Medical Prescription")

        info = _parse_prescription_text(treatment_text)

        # secondary guard after parsing
        has_real_content = any(
            [
                _clean(info.get("patient_name")),
                _clean(info.get("diagnosis")),
                any(info.get("left_notes", [])),
                any(info.get("sections", {}).get("Prescription", [])),
                any(info.get("sections", {}).get("Vitals", [])),
                any(info.get("sections", {}).get("Advice", [])),
                any(info.get("sections", {}).get("Investigations", [])),
                any(info.get("sections", {}).get("Follow-up", [])),
            ]
        )

        if not has_real_content:
            c.setFont(FONT_BOLD, 13)
            c.drawString(20 * mm, PAGE_H / 2 + 4 * mm, "No valid prescription content detected.")
            c.setFont(FONT_NAME, 10)
            c.drawString(20 * mm, PAGE_H / 2 - 2 * mm, "Please retry with a valid medical dictation or prescription text.")
            c.save()
            buffer.seek(0)
            return buffer.read()

        if not info.get("date"):
            info["date"] = datetime.now().strftime("%d/%m/%Y")

        right_flow = _build_right_flow_lines(
            info.get("sections", {}),
            RIGHT_MARGIN - RIGHT_COL_X - 4 * mm,
        )
        left_lines = _build_left_note_lines(
            info.get("left_notes", []),
            LEFT_COL_W - 5 * mm,
            info.get("date", ""),
        )

        temp_header_bottom = _draw_header(c, info, 1, 1)
        temp_diag_bottom = _draw_diagnosis_strip(c, info, temp_header_bottom - 4 * mm)
        body_top = temp_diag_bottom
        body_bottom = BOTTOM_MARGIN

        pages_payload = _paginate_flow(
            right_flow=right_flow,
            left_lines=left_lines,
            first_page_body_top=body_top,
            next_page_body_top=body_top,
            body_bottom=body_bottom,
        )

        total_pages = len(pages_payload)

        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        c.setTitle("Medical Prescription")

        for page_num, page_payload in enumerate(pages_payload, 1):
            header_bottom = _draw_header(c, info, page_num, total_pages)
            diag_bottom = _draw_diagnosis_strip(c, info, header_bottom - 4 * mm)
            _draw_body_page(c, page_payload, diag_bottom)
            _draw_footer(c)

            if page_num < total_pages:
                c.showPage()

        c.save()

    except Exception as e:
        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        c.setFont(FONT_NAME, 12)
        c.drawString(20 * mm, PAGE_H / 2, f"Error generating prescription: {str(e)}")
        c.save()

    buffer.seek(0)
    return buffer.read()