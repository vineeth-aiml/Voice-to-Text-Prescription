import json
from vosk import Model, KaldiRecognizer


class VoskTranscriber:
    def __init__(self, model_path: str, sample_rate: int = 16000):
        self.model = Model(model_path)
        self.sample_rate = sample_rate

    def create_recognizer(self):
        rec = KaldiRecognizer(self.model, self.sample_rate)
        rec.SetWords(True)
        return rec

    def transcribe_chunk(self, recognizer, pcm16_bytes: bytes):
        if recognizer.AcceptWaveform(pcm16_bytes):
            res = json.loads(recognizer.Result())
            text = (res.get('text') or '').strip()
            return {'type': 'segment', 'text': text} if text else None
        res = json.loads(recognizer.PartialResult())
        text = (res.get('partial') or '').strip()
        return {'type': 'partial', 'text': text} if text else None

    def final_result(self, recognizer) -> str:
        res = json.loads(recognizer.FinalResult())
        return (res.get('text') or '').strip()
