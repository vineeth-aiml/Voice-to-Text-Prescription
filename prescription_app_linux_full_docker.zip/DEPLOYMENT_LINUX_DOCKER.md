# Linux full Docker deployment

## Folder layout

```
prescription_app/
├── backend/
├── frontend/
├── llm/
├── models/
│   ├── model.gguf
│   └── vosk-model-small-en-in-0.4/
├── docker-compose.yml
├── .env
└── deploy.sh
```

## Prerequisites
- Ubuntu 22.04 or similar
- Docker + Docker Compose plugin
- Internet available at image build time, unless you prebuild images elsewhere

## Build and run
```bash
cp .env.example .env
chmod +x deploy.sh
./deploy.sh
```

Open `http://SERVER_IP:8080`

## Health checks
```bash
docker compose ps
docker compose logs -f backend
docker compose logs -f llm
```

Backend health:
```bash
curl http://127.0.0.1:8080/api/health || curl http://127.0.0.1:8080/health
```

## Offline / air-gapped deployment
Build on a connected Linux machine first:
```bash
docker compose build
docker save prescription_frontend prescription_backend prescription_llm -o prescription_images.tar
```

On offline server:
```bash
docker load -i prescription_images.tar
docker compose up -d
```

## Important
- Put the GGUF model at `models/model.gguf` unless you change the LLM container command.
- Put the Vosk folder at `models/vosk-model-small-en-in-0.4/`.
- Frontend is production-built and served by Nginx, not `npm start`.
- Clients only use browser; nothing is installed on client systems.
