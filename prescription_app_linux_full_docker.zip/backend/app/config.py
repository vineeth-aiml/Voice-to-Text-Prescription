import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

APP_NAME = os.getenv('APP_NAME', 'Prescription Realtime App')
CORS_ORIGINS = [o.strip() for o in os.getenv('CORS_ORIGINS', '*').split(',') if o.strip()]

VOSK_MODEL_PATH = os.getenv(
    'VOSK_MODEL_PATH',
    str(BASE_DIR / 'models' / 'vosk-model-small-en-in-0.4')
)

LLAMA_CHAT_URL = os.getenv('LLAMA_CHAT_URL', 'http://llm:8081/v1/chat/completions')
LLAMA_MODEL = os.getenv('LLAMA_MODEL', 'local')
LOG_DIR = os.getenv('LOG_DIR', str(BASE_DIR / 'logs'))
