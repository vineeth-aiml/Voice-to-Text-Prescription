import json
import os
from typing import Any, Dict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app.logger import get_logger
from app.config import APP_NAME, CORS_ORIGINS, VOSK_MODEL_PATH
from app.stt_vosk import VoskTranscriber
from app.llm_prescription import rx_from_text, rx_markdown
from app.pdf_export import prescription_text_to_pdf

logger = get_logger('main')
app = FastAPI(title=APP_NAME)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

print('Using Vosk model path:', VOSK_MODEL_PATH)

TRANSCRIBER = VoskTranscriber(model_path=VOSK_MODEL_PATH)


class RxRequest(BaseModel):
    text: str


class RxResponse(BaseModel):
    prescription: Dict[str, Any]
    markdown: str


class PdfRequest(BaseModel):
    text: str


@app.get('/health')
def health():
    return {'ok': True}


@app.post('/api/prescription', response_model=RxResponse)
def generate_prescription(req: RxRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail='Empty transcript')

    rx = rx_from_text(req.text)
    md = rx_markdown(rx)

    if not md:
        raise HTTPException(
            status_code=422,
            detail=rx.get("meta", {}).get(
                "rejection_reason",
                "No valid prescription content detected."
            )
        )

    return RxResponse(prescription=rx, markdown=md)


@app.post('/api/prescription/pdf')
def export_pdf(req: PdfRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail='Empty prescription')

    pdf_bytes = prescription_text_to_pdf(req.text)
    return StreamingResponse(
        iter([pdf_bytes]),
        media_type='application/pdf',
        headers={
            'Content-Disposition': 'attachment; filename=prescription.pdf',
            'Cache-Control': 'no-store'
        },
    )


@app.websocket('/ws/stt')
async def ws_stt(ws: WebSocket):
    await ws.accept()
    recognizer = None
    transcript_segments = []
    current_partial = ''
    try:
        while True:
            msg = await ws.receive()
            if 'text' in msg and msg['text']:
                data = json.loads(msg['text'])
                msg_type = data.get('type')
                if msg_type == 'start':
                    recognizer = TRANSCRIBER.create_recognizer()
                    transcript_segments = []
                    current_partial = ''
                    await ws.send_text(json.dumps({'type': 'started'}))
                elif msg_type == 'stop':
                    if recognizer:
                        final_tail = TRANSCRIBER.final_result(recognizer)
                        if final_tail:
                            transcript_segments.append(final_tail)
                        full_text = ' '.join(t.strip() for t in transcript_segments if t.strip())
                        full_text = ' '.join(full_text.split())
                        await ws.send_text(json.dumps({'type': 'final', 'text': full_text}))
                    await ws.close()
                    break
            if 'bytes' in msg and msg['bytes'] and recognizer:
                result = TRANSCRIBER.transcribe_chunk(recognizer, msg['bytes'])
                if not result:
                    continue
                if result['type'] == 'partial':
                    current_partial = result['text']
                    preview = ' '.join([*transcript_segments, current_partial]).strip()
                    await ws.send_text(json.dumps({'type': 'partial', 'text': preview}))
                elif result['type'] == 'segment':
                    seg = result['text'].strip()
                    if seg:
                        transcript_segments.append(seg)
                        current_partial = ''
                        await ws.send_text(json.dumps({'type': 'segment', 'text': ' '.join(transcript_segments).strip()}))
    except WebSocketDisconnect:
        logger.info('client disconnected')
    except Exception as e:
        logger.exception('websocket error')
        try:
            await ws.send_text(json.dumps({'type': 'error', 'message': str(e)}))
        except Exception:
            pass