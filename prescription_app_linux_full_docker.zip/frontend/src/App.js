import React, { useMemo, useRef, useState } from "react";
import "./styles.css";

const API_BASE = process.env.REACT_APP_API_BASE || "";
const WS_URL =
  process.env.REACT_APP_WS_URL ||
  `${window.location.protocol === "https:" ? "wss" : "ws"}://${window.location.host}/ws/stt`;

function pcmEncode(float32Array) {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < float32Array.length; i++) {
    let s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return buffer;
}

function MicIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2Z"
        fill="currentColor"
      />
    </svg>
  );
}

export default function App() {
  const sessionId = useMemo(
    () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    []
  );

  const [status, setStatus] = useState("Idle");
  const [recording, setRecording] = useState(false);

  const [transcript, setTranscript] = useState("");
  const [, setPrescriptionJson] = useState(null);
  const [prescriptionText, setPrescriptionText] = useState("");
  const [rxLoading, setRxLoading] = useState(false);

  const wsRef = useRef(null);
  const wsReadyRef = useRef(false);

  const audioCtxRef = useRef(null);
  const sourceRef = useRef(null);
  const processorRef = useRef(null);
  const streamRef = useRef(null);

  const ensureWs = () =>
    new Promise((resolve, reject) => {
      const existing = wsRef.current;
      if (existing && existing.readyState === 1 && wsReadyRef.current) {
        return resolve(existing);
      }

      setStatus("Connecting...");
      const ws = new WebSocket(WS_URL);
      ws.binaryType = "arraybuffer";
      wsRef.current = ws;
      wsReadyRef.current = false;

      let done = false;
      const ok = () => {
        if (!done) {
          done = true;
          resolve(ws);
        }
      };
      const err = (e) => {
        if (!done) {
          done = true;
          reject(e || new Error("WebSocket failed"));
        }
      };

      ws.onopen = () => {
        try {
          ws.send(
            JSON.stringify({
              type: "start",
              session_id: sessionId,
              sample_rate: 16000,
            })
          );
        } catch {}
      };

      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data);

          if (msg.type === "started") {
            wsReadyRef.current = true;
            setStatus("Ready");
            ok();
            return;
          }

          if (msg.type === "partial") {
            setTranscript(msg.text || "");
            setStatus("Listening...");
            return;
          }

          if (msg.type === "segment") {
            setTranscript(msg.text || "");
            setStatus("Listening...");
            return;
          }

          if (msg.type === "final") {
            setTranscript(msg.text || "");
            setStatus("Transcript Ready");
            return;
          }

          if (msg.type === "error") {
            setStatus("Error: " + (msg.message || "unknown"));
          }
        } catch (e) {
          console.error("WS parse error", e);
        }
      };

      ws.onerror = () => {
        setStatus("WS Error");
        err(new Error("WS error"));
      };

      ws.onclose = () => {
        wsReadyRef.current = false;
        setRecording(false);
        setStatus((prev) =>
          ["Transcript Ready", "Prescription Ready", "Generating Prescription..."].includes(prev)
            ? prev
            : "Disconnected"
        );
      };

      setTimeout(() => {
        if (!wsReadyRef.current) err(new Error("WS timeout"));
      }, 5000);
    });

  const startMic = async () => {
    await ensureWs();

    setTranscript("");
    setPrescriptionText("");
    setPrescriptionJson(null);

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    streamRef.current = stream;

    const AC = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AC({ sampleRate: 16000 });
    audioCtxRef.current = audioCtx;

    const src = audioCtx.createMediaStreamSource(stream);
    sourceRef.current = src;

    const proc = audioCtx.createScriptProcessor(4096, 1, 1);
    processorRef.current = proc;

    proc.onaudioprocess = (e) => {
      const w = wsRef.current;
      if (!w || w.readyState !== 1) return;
      const input = e.inputBuffer.getChannelData(0);
      w.send(pcmEncode(input));
    };

    src.connect(proc);
    proc.connect(audioCtx.destination);

    setRecording(true);
    setStatus("Listening...");
  };

  const stopMic = async () => {
    setRecording(false);

    const proc = processorRef.current;
    const src = sourceRef.current;
    const ctx = audioCtxRef.current;
    const stream = streamRef.current;

    processorRef.current = null;
    sourceRef.current = null;
    audioCtxRef.current = null;
    streamRef.current = null;

    try {
      if (proc) {
        proc.onaudioprocess = null;
        proc.disconnect();
      }
    } catch {}
    try {
      if (src) src.disconnect();
    } catch {}
    try {
      if (stream) stream.getTracks().forEach((t) => t.stop());
    } catch {}
    try {
      if (ctx && ctx.state !== "closed") await ctx.close();
    } catch {}

    try {
      const ws = wsRef.current;
      if (ws && ws.readyState === 1) {
        ws.send(JSON.stringify({ type: "stop", session_id: sessionId }));
      }
    } catch {}

    setStatus("Finalizing...");
  };

  const toggleDictate = async () => {
    try {
      if (recording) await stopMic();
      else await startMic();
    } catch (e) {
      console.error(e);
      setRecording(false);
      setStatus("Error");
    }
  };

  const generatePrescription = async () => {
    const t = (transcript || "").trim();
    if (!t || rxLoading) return;

    setRxLoading(true);
    setPrescriptionText("");
    setPrescriptionJson(null);
    setStatus("Generating Prescription...");

    try {
      const res = await fetch(`${API_BASE}/api/prescription`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: t }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data?.detail || "Prescription API failed");

      setPrescriptionJson(data.prescription || null);
      setPrescriptionText(data.markdown || "");
      setStatus("Prescription Ready");
    } catch (e) {
      setPrescriptionText("Prescription generation failed: " + String(e));
      setStatus("Prescription Error");
    } finally {
      setRxLoading(false);
    }
  };

  const exportPdf = async () => {
    const t = (prescriptionText || "").trim();
    if (!t) return;

    try {
      const res = await fetch(`${API_BASE}/api/prescription/pdf`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: t }),
      });

      if (!res.ok) throw new Error("PDF generation failed");

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "prescription.pdf";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setStatus("PDF Ready");
    } catch (e) {
      console.error(e);
      setStatus("PDF Export Error");
    }
  };

  const clearAll = () => {
    setTranscript("");
    setPrescriptionText("");
    setPrescriptionJson(null);
    setStatus("Ready");
  };

  return (
    <div className="page">
      <header className="header">
        <div>
          <div className="title">Voice Intelligence Prescription</div>
          <div className="subtitle">
            Dictate → stop → review transcript → generate prescription → edit → export PDF
          </div>
        </div>

        <button
          className={"micBtn " + (recording ? "active" : "")}
          onClick={toggleDictate}
          title={recording ? "Stop dictation" : "Start dictation"}
          aria-pressed={recording}
        >
          <MicIcon />
          <span>{recording ? "Stop" : "Dictate"}</span>
        </button>
      </header>

      <div className="card">
        <div className="statusRow">
          <div className="status">{status}</div>
          <div className="actions">
            <button className="btn" onClick={clearAll} disabled={!transcript && !prescriptionText}>
              Clear
            </button>
          </div>
        </div>

        <div className="panes">
          <div className="pane">
            <div className="label">Transcript Editor</div>
            <textarea
              className="box editor"
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              placeholder="Transcript will appear here. Edit it before generating the prescription."
            />
            <div className="rxRow">
              <button
                className="btn primary"
                onClick={generatePrescription}
                disabled={!transcript.trim() || rxLoading}
              >
                {rxLoading ? "Generating..." : "Generate Prescription"}
              </button>
            </div>
          </div>

          <div className="pane">
            <div className="label">Prescription Editor</div>
            <textarea
              className="box editor"
              value={prescriptionText}
              onChange={(e) => setPrescriptionText(e.target.value)}
              placeholder="Generated prescription will appear here. Edit it, then export PDF."
            />
            <div className="rxRow">
              <button
                className="btn success"
                onClick={exportPdf}
                disabled={!prescriptionText.trim()}
              >
                Export PDF
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}